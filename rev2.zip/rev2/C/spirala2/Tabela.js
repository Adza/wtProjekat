var Tabela=(function(){
    var containerId = "table-container";
    var tableElements = [
        {
            Sifra: 1,
            Repozitorij: 'www.google.com',
            Komentar: '',
            Ocjena: 1
        },
        {
            Sifra: 2,
            Repozitorij: 'www.google.com',
            Komentar: '',
            Ocjena: 1
        },
        {
            Sifra: 3,
            Repozitorij: 'www.google.com',
            Komentar: '',
            Ocjena: 1
        },
        {
            Sifra: 4,
            Repozitorij: 'www.google.com',
            Komentar: '',
            Ocjena: 1
        },
        {
            Sifra: 5,
            Repozitorij: 'www.google.com',
            Komentar: '',
            Ocjena: 1
        },
    ];

    var moveUp = function(index) {
        var elementIndex = 0;
        
        var elements = document.getElementsByClassName('element-id');

        for(var i=0; i<elements.length; i++)
            if(elements[i].innerHTML == index)
                elementIndex = i;

        if(elementIndex >= tableElements.length || elementIndex == 0)
            return;

        var tmp = tableElements[elementIndex];
        tableElements[elementIndex] = tableElements[elementIndex - 1];
        tableElements[elementIndex - 1] = tmp;

        renderTable();
    };

    var moveDown = function(index) {
        var elementIndex = 0;
        
        var elements = document.getElementsByClassName('element-id');

        for(var i=0; i<elements.length; i++)
            if(elements[i].innerHTML == index)
                elementIndex = i;

        

        if(elementIndex >= tableElements.length || elementIndex == tableElements.length - 1)
            return;
    
            var tmp = tableElements[elementIndex];
            tableElements[elementIndex] = tableElements[elementIndex + 1];
            tableElements[elementIndex + 1] = tmp;
        
            renderTable();
    }

    var renderTable = function() {
        var html =  '<table class="tg">' +
                        '<tr>' +
                            '<th class="tg-yw4l">Šifra studenta</th>' +
                            '<th class="tg-yw4l">Link do repozitorija</th>' +
                            '<th class="tg-yw4l">Input polje za tekst</th>' +
                            '<th class="tg-yw4l">Broj</th>' +
                            '<th class="tg-yw4l"></th>' +
                            '<th class="tg-yw4l"></th>' +
                        '</tr>';
        
        tableElements.forEach(function(element) {
            html += '<tr>' +
                        '<td class="tg-yw4l element-id">' + element.Sifra + '</td>' +
                        '<td class="tg-yw4l">' + element.Repozitorij + '</td>' +
                        '<td class="tg-yw4l">' +
                            '<input name="tekst" id="textInput" type="text" value="' + element.Komentar + '" />' +
                        '</td>' +
                        '<td class="tg-yw4l">' +
                            '<input type="number" name="broj" id="numInput" min="1" max="5" value="' + element.Ocjena + '">' +
                        '</td>' +
                        '<td class="tg-yw4l">' +
                            '<button type="submit" onclick="Tabela.moveUp(' + element.Sifra + ')";>Gore</button>' +
                        '</td>' +
                        '<td class="tg-yw4l">' +
                        '<button type="submit" onclick="Tabela.moveDown(' + element.Sifra + ')";>Dole</button>' +
                        '</td>' +
                    '</tr>';
        });

        html += '</table>';

        document.getElementById(containerId).innerHTML = html;
    };

    document.addEventListener("DOMContentLoaded", function() {
        renderTable();
      });

    return {
        moveUp: moveUp,
        moveDown: moveDown,
        renderTable: renderTable  
    }

}());