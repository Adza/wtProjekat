var Poruke=(function(){
    var containerId = "message-container";
    var possibleMessages = ['Email koji ste napisali nije validan fakultetski email',
                        'Indeks kojeg ste napisali nije validan',
                        'Nastavna grupa koju ste napisali nije validna',
                        'Ime i prezime nije validno',
                        'Password nije validan',
                        'Potvrda passworda nije validna',
                        'Bitbucker URL nije validan',
                        'Bitbucket SSH nije validan',
                        'Naziv repozitorija nije validan',
                        'Akademska godina nije validna'];
    var messagesForDisplay = [];

    var ispisiGreske = function() {
        var container = document.getElementById(containerId);
        container.innerHTML = '';

        messagesForDisplay.forEach(function(element){
            container.innerHTML += '<div>' + element + '</div>';
        });

        messagesForDisplay = [];
    };


    var postaviIdDiva = function(id) {
        var element = document.getElementById(containerId);
        element.setAttribute('id', id);
    };

    var dodajPoruku = function(index) {
        if(index >= possibleMessages.length)
            return;
        
        if(messagesForDisplay.indexOf(possibleMessages[index]) == -1)
            messagesForDisplay.push(possibleMessages[index]);
    };

    var ocistiGresku = function(index) {
        if(index >= possibleMessages.length)
            return;
        
        messagesForDisplay = messagesForDisplay.splice(index, 1);
    };

    return {
        ispisiGreske: ispisiGreske,
        postaviIdDiva: postaviIdDiva,
        dodajPoruku: dodajPoruku,
        ocistiGresku: ocistiGresku
    }

    }());