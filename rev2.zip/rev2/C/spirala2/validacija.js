var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
    var fakultetskaDomena = "@etf.unsa.ba";
    var godina = new Date().getFullYear();

    var validirajFakultetski = function(string){
        if(string.length == 0)
            return false;
            
        var s = string;
        var pos = s.indexOf("@");
        var pos2 = s.lastIndexOf("@");
        if (pos != pos2) 
            return false;
        if (s[pos+fakultetskaDomena.length+1] == undefined) 
            return true;
        return false;     
    }

    var validirajIndex = function (number){
        return (number.toString().indexOf("1")=="0" && number.toString().length == 5);
    }

    var validirajGrupu = function (number){
        return (parseInt(number)>=1 && parseInt(number)<=maxGrupa);
    }
    
    var validirajAkGod = function (string){
        return (string.length > 0 && (string.substr(0,4) == godina.toString() || string.substr(5,4) == godina.toString()) && string.length == 9 && string[4] == "/" && string.substr(0,2) == string.substr(5,2) && string.substr(5,2)=="20" && parseInt(string.substr(2,2)) + 1 == parseInt(string.substr(7,2)));
    }

    var validirajPassword = function (string){
        return (string.length > 0 && (string.search(/[a-z]/g) != -1) && 
        (string.search(/[A-Z]/g)) != -1 && 
        (string.search(/[0-9]/g) != -1) && 
        string.length > 6 && 
        string.length < 21);
    }

    var validirajPotvrde = function (str1, str2){
        return (str1 == str2 && validirajPassword(str1));
    }

    var validirajBitbucketUrl = function (string){
        return ((string.length > 0 && string.substr(0,8) == "https://") && 
        string.substr(string.indexOf("@"),15) == "@bitbucket.org/" && 
        /^[/]{4}$/ && (string.indexOf(".git") !== -1) &&
        string.substring(string.length-4) == ".git" &&
        string.replace(/[^/]/g, "").length == "4"
    );
    }

    var validirajBitbucketSSH = function(string) {
        return (string.substr(0,17) == "git@bitbucket.org" && 
        string[18] == ":" &&
        string.replace(/[^/]/g, "").length == "1" &&
        string.substring(string.length-4) == ".git"
    );
    }

    var validirajNazivRepozitorija = function(regex, string) {
        if(regex)
            return string.search(regex);
        else
            return(string.toLower().indexOf('wtprojekat') != -1 && validirajIndex(parseInt(string.substring(string[10], string.length-1))));
    }    

    var validirajImeiPrezime = function(ime) {
        return (ime.length > 0 && 
        (ime.search(/[a-z]/g) != -1) && 
        (ime.search(/[A-Z]/g)) != -1 && 
        (
            ime.substr(0, parseInt(ime.indexOf(" "))).length < 13 && ime.substr(0, ime.indexOf(" ")).length > 3
            ||
            ime.substring(parseInt(ime.indexOf(" "))).length < 13 && ime.substring(parseInt(ime.indexOf(" "))).length > 3
        ) &&
        ime.replace(/[^-]/g, "").length <= "2" &&
        ime.replace(/[^']/g, "").length <= "2" &&
        ime[ime.indexOf(" ")+1] != "-" && string[0] != "'" &&
        string[0] != "-" 
        );
    }    

    var postaviMaxGrupa = function(ime) {
        return true;
    }

    var postaviTrenSemestar = function(ime) {
        return true;
    }


    return{
    validirajFakultetski: validirajFakultetski,
    validirajIndex: validirajIndex,
    validirajGrupu: validirajGrupu,
    validirajAkGod: validirajAkGod,
    validirajPassword: validirajPassword,
    validirajPotvrdu: validirajPotvrde,
    validirajBitbucketURL: validirajBitbucketUrl,
    validirajBitbucketSSH: validirajBitbucketSSH,
    validirajNazivRepozitorija:validirajNazivRepozitorija,
    validirajImeiPrezime: validirajImeiPrezime,
    postaviMaxGrupa: postaviMaxGrupa,
    postaviTrenSemestar: postaviTrenSemestar
    }
    }());