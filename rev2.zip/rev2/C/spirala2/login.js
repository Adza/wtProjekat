function nastavnikForma() {
    var container = document.getElementById('registracija');

    var html =      '<button type="submit" class="btn-default" onclick="studentForma()">Registruj studenta</button>' +
                    '<button type="submit" class="btn-default" onclick="nastavnikForma()">Registruj nastavnika</button>' +
                    '<h2>Registruj nastavnika</h2>' +
                    '<p>Ime i prezime</p>' +
                    '<input id="ime" type="text" onfocusout="if(!Validacija.validirajImeiPrezime(this.value)) Poruke.dodajPoruku(3)">' +
                    '<p>Korisnicko ime</p>' +
                    '<input type="text">' +
                    '<p>Password</p>' +
                    '<input id="pw" type="Password" onfocusout="if(!Validacija.validirajPassword(this.value)) Poruke.dodajPoruku(4)">' +
                    '<p>Potvrda passworda</p>' +
                    '<input id="pwp" type="password" onfocusout="if(!Validacija.validirajPotvrdu(this.value)) Poruke.dodajPoruku(5)">' +
                    '<p>Fakultetski mail</p>' +
                    '<input id="mail" type="email" onfocusout="if(!Validacija.validirajFakultetski(this.value)) Poruke.dodajPoruku(0)">' +
                    '<p>Broj grupa</p>' +
                    '<input type="number" min="1" onfocusout="Validacija.postaviMaxGrupa(this.value)">' +
                    '<p>Regex za naziv repozitorija</p>' +
                    '<input type="text">' + 
                    '<p>Trenutni semestar</p>' +
                    '<input type="number" min="0" max="1">' +
                    '<p>Akademska godina</p>' +
                    '<input id="akGod" type="text" onfocusout="if(!Validacija.validirajAkGod(this.value)) Poruke.dodajPoruku(9)">' +
                    '<button type="submit" class="btn-default" onclick="validirajNastavnik();">Registruj</button>' +
                    '<div id="message-container"></div>';

    container.innerHTML = html;
}

function studentForma() {
    var container = document.getElementById('registracija');

    var html =      '<button type="submit" class="btn-default" onclick="studentForma()">Registruj studenta</button>' +
                    '<button type="submit" class="btn-default" onclick="nastavnikForma()">Registruj nastavnika</button>' +
                    '<h2>Registruj studenta</h2>' +
                    '<p>Ime i prezime</p>' +
                    '<input id="ime" type="text" onfocusout="if(!Validacija.validirajImeiPrezime(this.value)) Poruke.dodajPoruku(3)">' +
                    '<p>Broj indexa</p>' +
                    '<input id="index" type="text" onfocusout="if(!Validacija.validirajIndex(this.value)) Poruke.dodajPoruku(1)">' +
                    '<p>Broj grupe</p>' +
                    '<input id="grupa" type="number" min="1" onfocusout="if(!Validacija.validirajGrupu(this.value)) Poruke.dodajPoruku(2)">' +
                    '<p>Akademska godina</p>' +
                    '<input id="akGod" type="text" onfocusout="if(!Validacija.validirajAkGod(this.value)) Poruke.dodajPoruku(9)">' +
                    '<p>Password</p>' +
                    '<input id="pw" type="Password" onfocusout="if(!Validacija.validirajPassword(this.value)) Poruke.dodajPoruku(4)">' +
                    '<p>Potvrda passworda</p>' +
                    '<input id="pwp" type="password" onfocusout="if(!Validacija.validirajPotvrdu(this.value)) Poruke.dodajPoruku(5)">' +
                    '<p>Bitbucket URL</p>' +
                    '<input id="bbUrl" type="text" onfocusout="if(!Validacija.validirajBitbucketURL(this.value)) Poruke.dodajPoruku(6)">' + 
                    '<p>Bitbucket SSH</p>' +
                    '<input id="bbSsh" type="text" onfocusout="if(!Validacija.validirajBitbucketSSH(this.value)) Poruke.dodajPoruku(7)">' + 
                    '<p>Naziv repozitorija</p>' +
                    '<input id="bbRep" type="text" onfocusout="if(!Validacija.validirajNazivRepozitorija(this.value)) Poruke.dodajPoruku(8)">' + 
                    '<button type="submit" class="btn-default" onclick="validirajStudent();">Registruj</button>' + 
                    '<div id="message-container"></div>';

    container.innerHTML = html;
}

var validirajNastavnik = function() {
    var ime = document.getElementById('ime');
    var akGod = document.getElementById('akGod');
    var pw = document.getElementById('pw');
    var pwp = document.getElementById('pwp');
    var mail = document.getElementById('mail');

    if(!Validacija.validirajImeiPrezime(ime.value)) 
        Poruke.dodajPoruku(3);


    if(!Validacija.validirajAkGod(akGod.value)) 
        Poruke.dodajPoruku(9);

    if(!Validacija.validirajPassword(pw.value)) 
        Poruke.dodajPoruku(4);

    if(!Validacija.validirajPotvrdu(pwp.value)) 
        Poruke.dodajPoruku(5);

    if(!Validacija.validirajFakultetski(mail.value)) 
        Poruke.dodajPoruku(0);

    Poruke.ispisiGreske();
}

var validirajStudent = function() {
    var ime = document.getElementById('ime');
    var index = document.getElementById('index');
    var grupa = document.getElementById('grupa');
    var akGod = document.getElementById('akGod');
    var pw = document.getElementById('pw');
    var pwp = document.getElementById('pwp');
    var bbUrl = document.getElementById('bbUrl');
    var bbSsh = document.getElementById('bbSsh');
    var bbRep = document.getElementById('bbRep');

    if(!Validacija.validirajImeiPrezime(ime.value)) 
        Poruke.dodajPoruku(3);

    if(!Validacija.validirajIndex(index.value)) 
        Poruke.dodajPoruku(1);
    
    if(!Validacija.validirajGrupu(grupa.value)) 
        Poruke.dodajPoruku(2);

    if(!Validacija.validirajAkGod(akGod.value)) 
        Poruke.dodajPoruku(9);

    if(!Validacija.validirajPassword(pw.value)) 
        Poruke.dodajPoruku(4);

    if(!Validacija.validirajPotvrdu(pwp.value)) 
        Poruke.dodajPoruku(5);

    if(!Validacija.validirajBitbucketURL(bbUrl.value)) 
        Poruke.dodajPoruku(6);

    if(!Validacija.validirajBitbucketSSH(bbSsh.value)) 
        Poruke.dodajPoruku(7);

    if(!Validacija.validirajNazivRepozitorija(bbRep.value)) 
        Poruke.dodajPoruku(8);

    Poruke.ispisiGreske();
}

document.addEventListener("DOMContentLoaded", function() {
    studentForma();
});