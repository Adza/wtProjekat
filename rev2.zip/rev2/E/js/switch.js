function shift(element, smjer) {
    if(smjer == "up") {
        var trenutni = element.parentNode.parentNode;
        var iznad = element.parentNode.parentNode.previousElementSibling;
        if(iznad.className!="header")
        iznad.parentNode.insertBefore(trenutni, iznad);
    } else {
        var trenutni = element.parentNode.parentNode;
        var ispod = element.parentNode.parentNode.nextElementSibling;
        if(ispod!=null)
        trenutni.parentNode.insertBefore(ispod, trenutni);
    }
}