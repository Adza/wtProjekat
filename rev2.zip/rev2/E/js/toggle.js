function otvoriStudent() {
    document.getElementById("registracija-studenta").style.display = "block";
    document.getElementById("registracija-nastavnika").style.display = "none";
    /* document.getElementById("nast").style='none';
    document.getElementById("stud").style.boxShadow='0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)';
    document.getElementById("stud").style.fontSize='18px';
    document.getElementById("stud").style.color='yellow'; */
    document.getElementById("nast").className = "button";
    document.getElementById("stud").className = "button naglasena";

}

function otvoriNastavnik() {
    document.getElementById("registracija-studenta").style.display = "none";
    document.getElementById("registracija-nastavnika").style.display = "block";
    /*document.getElementById("nast").style.boxShadow='0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)';
    document.getElementById("nast").style.fontSize='18px';
    document.getElementById("nast").style.color='yellow';
    document.getElementById("stud").style='none'; */
    document.getElementById("nast").className = "button naglasena";
    document.getElementById("stud").className = "button";
    
}