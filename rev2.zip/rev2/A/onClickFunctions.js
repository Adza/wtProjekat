var sviThumbsUpovi = document.getElementsByClassName("gore");
for(var i = 0; i < sviThumbsUpovi.length; i++){
    sviThumbsUpovi[i].onclick = function(){
        var red = this.parentNode;
        var redIznad = red.parentNode;
        sljedeci = redIznad.previousElementSibling;
        if(!(sljedeci.id == "naslovnired")){
            roditelj = redIznad.parentNode;
            roditelj.insertBefore(redIznad, sljedeci);
        }
    }
}

var sviThumbsDownovi = document.getElementsByClassName("dole");
for(var i = 0; i < sviThumbsDownovi.length; i++){
    sviThumbsDownovi[i].onclick = function(){
        var red = this.parentNode;
        var redIspod = red.parentNode;
        sljedeci = redIspod.nextElementSibling;
        if(sljedeci !== null){
            
        roditelj = redIspod.parentNode;
        roditelj.insertBefore(sljedeci, redIspod);
        }
    }
}



