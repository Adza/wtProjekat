var validacija = (function () {
    var maxGrupa = 7;
    var trenutniSemestar = 0; //0 za zimski, 1 za ljetni semestar
    return {
        validirajFakultetski: function(email)
        {
            var re = /\w+@etf\.unsa\.ba$/;
            return email.match(re);
        } ,
            
        validirajIndex: function(index)
        {
            var re = /^1\d\d\d\d$/;
            return index.match(re);
        },

        validirajGrupu: function(grupa)
        {
            return ((grupa>=1)&&(grupa<=maxGrupa));
        },

        validirajAkGod: function (akGod)
        {
            //substring za brojeve
            var br1 = parseInt(akGod.substr(0,4));
            var br2 = parseInt(akGod.substr(5,9));
            var re = /^20\d\d\/20\d\d$/;
            var trenutna = (new Date()).getFullYear();
            if (!akGod.match(re) || br2-br1!==1) return false;
            return trenutniSemestar==0 ? br1 == trenutna : br2 == trenutna;
        },

        validirajPassword: function(password)
        {
            if (password.length<7 || password.length>20) return false;
            //bar jedno velko bar jedno malo i bar jedan broj
            var re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/;
            return password.match(re);
        },

        validirajPotvrdu: function (pw1, pw2)
        {
            if (pw1===pw2) return true;
            return false;
        },
        validirajBitbucketURL: function(url)
        {
            var re = /^https:\/\/\w+@bitbucket\.org\/\w+\/\w+\.git$/;
            return url.match(re);
        },

        validirajBitbucketSSH: function(ssh)
        {
            var re = /^git@bitbucket\.org:\w+\/\w+\.git$/;
            return ssh.match(re);
        },

        validirajNazivRepozitorija: function(regex, nazivRepo)
        {
            if (regex!=null) return nazivRepo.match(regex);
            var re1 =/^wtProjekat1\d\d\d\d$/;
            var re2 = /^wtprojekat1\d\d\d\d$/;
            return (nazivRepo.match(re1) || nazivRepo.match(re2)); 
        },

        validirajImeiPrezime: function(ime)                            
        {
            var re = /^([A-ZŠĐŽČĆ]([a-zšđžčć]{2,12})[ '-]*)+$/;
            return ime.match(re);
        },

        postaviMaxGrupa: function(grupa)
        {
            alert("postavi max grupa");
            maxGrupa=grupa;
        },
        postaviTrenSemestar: function(semestar)
        {
            trenutniSemestar=semestar;
        }
    }   
}());