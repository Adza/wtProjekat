var Poruke = (function () {
    var idDivaPoruka;
    var mogucePoruke = [" Email nije validan", " Indeks nije validan", " Grupa nije validna", " Akademska godina nije validna", " Password nije validan", " Passwordi nisu isti", " Bitbucket URL nije ispravan", " Bitbucket SSH nije ispravan", " Naziv repozitorija nije ispravan", " Ime i prezime nije ispravno"];
    var porukeZaIspis = [];
    return {
        ispisiGreske: function () {
            document.getElementById(idDivaPoruka).innerHTML = porukeZaIspis;
        },

        postaviIdDiva: function (divid) {
            idDivaPoruka = divid;
        },

        dodajPoruku: function (broj) {
            if (!porukeZaIspis.find(poruka => poruka == mogucePoruke[broj] && porukeZaIspis.length < 10)) {
                porukeZaIspis.push(mogucePoruke[broj]);
            }
        },

        ocistiGresku: function (broj) {
            var poruka = mogucePoruke[broj];
            if (broj >= 0 && broj <= mogucePoruke.length) {
                for (var i = 0; i < porukeZaIspis.length; i++) {
                    if (porukeZaIspis[i] === poruka) {
                        var temp = porukeZaIspis[i];
                        porukeZaIspis[i] = porukeZaIspis[porukeZaIspis.length-1];
                        porukeZaIspis[porukeZaIspis.length-1] = temp;
                        porukeZaIspis.splice(porukeZaIspis.length-1, 1);
                    }
                }
            }
        },

        ocistiPoruke: function () {
            porukeZaIspis = [];
        },
    }
}());