var pass;

function validirajIme(value) {
    if (!validacija.validirajImeiPrezime(value)) {
        Poruke.dodajPoruku(9);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(9);
        Poruke.ispisiGreske();
    }
}

function validirajFakultetski(value) {
    if (!validacija.validirajFakultetski(value)) {
        Poruke.dodajPoruku(0);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(0);
        Poruke.ispisiGreske();
    }
}

function validirajBrojIndeksa(value) {
    if (!validacija.validirajIndex(value)) {
        Poruke.dodajPoruku(1);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(1);
        Poruke.ispisiGreske();
    }
}

function validirajGrupu(value) {
    if (!validacija.validirajGrupu(value)) {
        Poruke.dodajPoruku(2);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(2);
        Poruke.ispisiGreske();
    }
}

function validirajAkaGod(value) {
    if (!validacija.validirajAkGod(value)) {
        Poruke.dodajPoruku(3);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(3);
        Poruke.ispisiGreske();
    }
}

function validirajPassword(value) {
    if (!validacija.validirajPassword(value)) {
        Poruke.dodajPoruku(4);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(4);
        Poruke.ispisiGreske();
    }
    pass = value;
}

function validirajPotvrdu(value) {
    if (!validacija.validirajPotvrdu(value, pass)) {
        Poruke.dodajPoruku(5);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(5);
        Poruke.ispisiGreske();
    }
}

function validirajBitURL(value) {
    if (!validacija.validirajBitbucketURL(value)) {
        Poruke.dodajPoruku(6);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(6);
        Poruke.ispisiGreske();
    }
}

function validirajBitSSH(value) {
    if (!validacija.validirajBitbucketSSH(value)) {
        Poruke.dodajPoruku(7);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(7);
        Poruke.ispisiGreske();
    }
}

function validirajNazivRepo(value) {
    if (!validacija.validirajNazivRepozitorija(null, value)) {
        Poruke.dodajPoruku(8);
        Poruke.postaviIdDiva("porukeContainer");
        Poruke.ispisiGreske();
    } else {
        Poruke.ocistiGresku(8);
        Poruke.ispisiGreske();
    }
}

function promijeniFormuStudent() {


    document.getElementById("registracijaStudent-container").style.display = "none";
    document.getElementById("registracijaProfesor-container").style.display = "block";
    document.getElementById("regNaslov").innerHTML = "Registracija profesora";

    Poruke.ocistiPoruke();
    Poruke.ispisiGreske();
}

function promijeniFormuProfesor() {

    document.getElementById("registracijaProfesor-container").style.display = "none";
    document.getElementById("registracijaStudent-container").style.display = "block";
    document.getElementById("regNaslov").innerHTML = "Registracija studenta";

    Poruke.ocistiPoruke();
    Poruke.ispisiGreske();
}