/*Funkcije pozvane na evente iz login.html templatea*/

function prikaziNastavnik()
{
    nastavnik = document.getElementById('nastavnik');
    student = document.getElementById('student');
    nastavnik.style.display = "block";
    student.style.display = "none";
    ocistiSveElemente();
    Poruke.ocistiSveGreske();
    Poruke.ispisiGreske();
}

function prikaziStudent()
{
    nastavnik = document.getElementById('nastavnik');
    student = document.getElementById('student');
    ocistiSveElemente();
    Poruke.ocistiSveGreske();
    Poruke.ispisiGreske();
    if(student.style.display === "none")
    {
        nastavnik.style.display = "none";
        student.style.display = "block";
    }
}
function ocistiSveElemente()
{
    var inputi = document.getElementsByTagName('input');
    for(var i = 0 ; i < inputi.length; i ++)
    {
        if(inputi[i].type != "submit")
            inputi[i].value = '';
    }
}

/*0: 'Email koji ste napisali nije validan fakultetski email',
  1: 'Indeks kojeg ste napisali nije validan',
  2: 'Nastavna grupa koju ste napisali nije validna',
  3: 'Bitbucket URL nije validan',
  4: 'Bitbucket SSH nije validan',
  5: 'Naziv repozitorija nije validan',
  6: 'Sifra nije validna',
  7: 'Potvrda sifre se ne poklapa sa originalom',
  8: 'Ime i prezime nije validno',
  9: 'Broj grupe nije validan',
  10:'Akademska godina nije validna'*/

function allPowerful(uslov, idPoruke)
{
    if(!uslov)
        Poruke.dodajPoruku(idPoruke);
    else
        Poruke.ocistiGresku(idPoruke);
    Poruke.ispisiGreske();
}
function uValidirajIme()
{
    var uslov = Validacija.validirajImeiPrezime(document.getElementById('nastavnikImePrezime').value);
    allPowerful(uslov,8);
}

function uValidirajPassword()
{
    var uslov = Validacija.validirajPassword(document.getElementById('nastavnikPassword').value);
    allPowerful(uslov,6);
}
function uValidirajPotvrdu()
{
    var uslov = Validacija.validirajPotvrdu(document.getElementById('nastavnikPassword').value, document.getElementById('nastavnikPotvrda').value);
    allPowerful(uslov,7);
}
function uValidirajEmail()
{
    var uslov = Validacija.validirajFakultetski(document.getElementById('nastavnikEmail').value);
    allPowerful(uslov,0);
}
function uValidirajAkGod()
{
    var uslov = Validacija.validirajAkGod(document.getElementById('nastavnikAkGod').value);
    allPowerful(uslov,10);
}

function uValidirajStIme()
{
    var uslov = Validacija.validirajImeiPrezime(document.getElementById('studentIme').value);
    allPowerful(uslov,8);
}
function uValidirajIndeks()
{
    var uslov = Validacija.validirajIndex(document.getElementById('studentIndeks').value);
    allPowerful(uslov,1);
}
function uValidirajGrupu()
{
    var uslov = Validacija.validirajGrupu(document.getElementById('studentGrupe').value);
    allPowerful(uslov,9);
}
function uValidirajStAk()
{
    var uslov = Validacija.validirajAkGod(document.getElementById('studentAkGod').value);
    allPowerful(uslov,10);
}
function uValidirajStPass()
{
    var uslov = Validacija.validirajPassword(document.getElementById('studentPassword').value);
    allPowerful(uslov,6);
}
function uValidirajStPotvrdu()
{
    var uslov = Validacija.validirajPotvrdu(document.getElementById('studentPassword.value'),document.getElementById('studentPotvrda').value);
    allPowerful(uslov,7);
}
function uValidirajURL()
{
    var uslov = Validacija.validirajBitbucketURL(document.getElementById('studentURL').value);
    allPowerful(uslov,3);
}
function uValidirajSSH()
{
    var uslov = Validacija.validirajBitbucketSSH(document.getElementById('studentSSH').value);
    allPowerful(uslov,4);
}
function uValidirajrepo()
{
    var uslov = Validacija.validirajNazivRepozitorija(document.getElementById('studentRepo').value);
    allPowerful(uslov,5);
}
function uPostaviMax()
{
    console.log(document.getElementById('nastavnikMaxGroup').value);
    Validacija.postaviMaxGrupa(document.getElementById('nastavnikMaxGroup').value);
}