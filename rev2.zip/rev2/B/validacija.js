var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0; //0 za zimski, 1 za ljetni semestar ??
    
    return{
        // Funkcija za validaciju fakultetskog maila
    validirajFakultetski: function(email){
        var regexMail = /^[a-z][a-z1-9]*\@etf\.unsa\.ba$/g;
        return !!(email.match(regexMail));
    },
        // Funkcija za validaciju indeksa
    validirajIndex: function(indeks)
    {
        var regexIndeks = /^(1)[0-9]{4}$/g;
        return !!(indeks.match(regexIndeks));
    },
        // Funkcija za validaciju nastavne grupe
    validirajGrupu: function(grupa)
    {
        return !!(parseInt(grupa) >= 1 && parseInt(grupa) <= parseInt(maxGrupa));
    },
        // Funkcija za validaciju akademske godine
    validirajAkGod: function(godina)
    {
        var regexGodina = /^20[0-9]{2}\/20[0-9]{2}$/g;
        var prvaGod = parseInt(godina.substring(0, 4));
        var drugaGod = parseInt(godina.substring(5, godina.length));
        return !!godina.match(regexGodina) && (drugaGod-prvaGod === 1);
    },
        // Funkcija za validaciju passworda
    validirajPassword: function(pass)
    {
        var regexPass = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}/g;
        return !!(pass.match(regexPass));
    },
        // Funkcija za validaciju potvrde passworda
    validirajPotvrdu: function(pass, potvrda)
    {
        var regexPass = /(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}/g;
        return !!(pass === potvrda && !!pass.match(regexPass) && !!potvrda.match(regexPass));
    },
        // Funkcija za validaciju bitbucket URL
    validirajBitbucketURL: function(link)
    {
        var regexBucket = /^https:\/\/[a-zA-Z0-9][a-zA-Z0-9]*@bitbucket\.org\/[a-zA-Z0-9][a-zA-Z0-9]*\/[a-zA-Z0-9][a-zA-Z0-9]*\.git$/g;
        return !!(link.match(regexBucket));
    },
        // Funkcija za validaciju bitbucket SSH    
    validirajBitbucketSSH: function(link)
    {
        var regexSSH = /^git@bitbucket\.org:[a-zA-Z0-9][a-zA-Z0-9]*\/[a-zA-Z0-9][a-zA-Z0-9]*\.git$/g
        return !!(link.match(regexSSH));
    },
        // Funkcija za validaciju repozitorija 
    validirajNazivRepozitorija: function(regex, repozitorij)
    {
        regexDefault = /^(wtProjekat1[0-9]{4}|wtprojekat1[0-9]{4})$/g;
        if(regex === "")
        {
            return !!(repozitorij.match(regexdefault));
        }
        else
            return !!(repozitorij.match(regex));
    },
        // Funkcija za validaciju imena
    validirajImeiPrezime: function(ime)
    {
        var regexIme = /^[A-ZŠĐČĆŽ][a-z-'čćžđš]{2,11}(\s[A-ZŠĐČĆŽ][a-z-'čćžđš]{2,11})*$/g;
        return !!(ime.match(regexIme));
    },
        // Funkcije za postavljanje varijabli  
    postaviMaxGrupa: function(parametar)
    {
        maxGrupa = parametar;
    },
    postaviTrenSemestar: function(parametar)
    {
        trenutniSemestar = parametar;
    }
    }
}());
    