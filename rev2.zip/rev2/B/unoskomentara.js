function dajGornjiRed(red)
{
    return red.previousElementSibling;
}

function dajLajk()
{
    var tabela, red = this.parentNode;
    while(red.nodeName != "TR")
        red = red.parentNode;

    tabela = red.parentNode;
    var gornjiRed = dajGornjiRed(red);
    //console.log(gornjiRed);
    if(gornjiRed != null && document.getElementsByTagName("tr")[1] != red)
        tabela.insertBefore(red,gornjiRed);
}
function dajDonjiRed(red)
{
    return red.nextElementSibling;
}
function dajDislajk()
{
    var tabela, red = this.parentNode;
    while(red.nodeName != "TR")
        red = red.parentNode;

    tabela = red.parentNode;
    var donjiRed = dajDonjiRed(red);
    //console.log(donjiRed);
    if(donjiRed != null)
        tabela.insertBefore(red,dajDonjiRed(donjiRed));
}
