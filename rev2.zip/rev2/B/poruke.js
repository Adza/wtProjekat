var Poruke=(function(){
    var idDivaPoruka;
    var mogucePoruke = ['GRESKA: Email koji ste napisali nije validan fakultetski email',
    'GRESKA: Indeks kojeg ste napisali nije validan',
    'GRESKA: Nastavna grupa koju ste napisali nije validna',
    'GRESKA: Bitbucket URL nije validan',
    'GRESKA: Bitbucket SSH nije validan',
    'GRESKA: Naziv repozitorija nije validan',
    'GRESKA: Sifra nije validna',
    'GRESKA: Potvrda sifre se ne poklapa sa originalom',
    'GRESKA: Ime i prezime nije validno',
    'GRESKA: Broj grupe nije validan',
    'GRESKA: Akademska godina nije validna'];

    var porukeZaIspis=[];
    return{
        ocistiSveGreske: function()
        {
            for(var i = 0; i < porukeZaIspis.length; i++)
                porukeZaIspis.splice(i,1);
        },
        ispisiGreske: function()
        {
            var ispis = '';
            document.getElementById('greske').innerHTML = "";
            for(var i = 0; i < porukeZaIspis.length; i++)
            {
                if(typeof porukeZaIspis[i] == "undefined")
                    continue;
                else
                    ispis += porukeZaIspis[i] + '<br>';
            }
            document.getElementById('greske').style.height = "auto";
            document.getElementById('greske').innerHTML += ispis;
        },
        postaviIdDiva: function(ID)
        {
            document.getElementById('greske').id = ID;
        },
        dodajPoruku: function(indexPoruke)
        {
            if(!porukeZaIspis.includes(mogucePoruke[indexPoruke]))
                porukeZaIspis.push(mogucePoruke[indexPoruke]);
        },
        ocistiGresku: function(indexGreske)
        {
            // funkcija koja brise iz niza gresku (ako postoji)
            for(var i = 0; i< porukeZaIspis.length; i++)
            {
                if(mogucePoruke[indexGreske] == porukeZaIspis[i])
                {
                    porukeZaIspis.splice(i,1);
                    break;
                }
            }
        }
    }
})();
