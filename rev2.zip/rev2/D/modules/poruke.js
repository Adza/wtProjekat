var Poruke = (function() {
  var idDivaPoruka;
  var mogucePoruke = [
    "Korisničko ime koje ste napisali nije validno", //
    "Email koji ste napisali nije validan fakultetski email", //
    "Indeks kojeg ste napisali nije validan", //
    "Nastavna grupa koju ste napisali nije validna", // ovo treba bit
    "Trenutni semestar koji ste napisali nije validan",
    "Akademska godina koju ste napisali nije validna", //
    "Password koji ste napisali nije validan", //
    "Potvrda passworda nije identična passwordu", //
    "Bitbucket URL koji ste napisali nije validan", //
    "Bitbucket SSH koji ste napisali nije validan", //
    "Naziv repozitorija koji ste napisali nije validan", //
    "Ime i prezime koje ste napisali nisu validni" //
  ]
  var porukeZaIspis = [];

  return {
    ispisiGreske: function() {
      theParent = document.getElementById(idDivaPoruka);
      theParent.innerHTML = "";
      for (i = 0; i < porukeZaIspis.length; i++) {
        theKid = document.createElement("div");
        theKid.innerHTML = porukeZaIspis[i];
        theParent.append(theKid);
      }
    },
    postaviIdDiva: function(idDiva) {
      idDivaPoruka = idDiva;
    },
    dodajPoruku: function(indexPoruke) {
      var indexIspis = porukeZaIspis.indexOf(mogucePoruke[indexPoruke]);
      if (indexIspis == -1) {
        //ako ne postoji dodati
        porukeZaIspis.push(mogucePoruke[indexPoruke])
      }
    },
    ocistiGresku: function(indexGreske) {
      var indexIspis = porukeZaIspis.indexOf(mogucePoruke[indexGreske]);
      if (indexIspis != -1) {
        //ako postoji obrisati
        porukeZaIspis.splice(indexIspis, 1);
      }

    }

  }
}());


// Funkcija ipisiGreske ne prima parametre i nema povratnu vrijednost. Funkcija
// postaviIdDiva prima parametar koji predstavlja id diva i nema povratnu vrijednost.
// Funkcija dodajPoruku prima kao parametar broj od 0 do maksimalnog broja
// mogućih poruka i dodaje odgovarajuću poruku u niz poruke za ispis, nema
// povratnu vrijednost. Funkcija ocistiGresku prima kao parametar broj od 0 do
// maksimanlog broja mogucih poruka i izbacuje iz niza poruka za ispis navedenu
// poruku (ako ona postoji).
