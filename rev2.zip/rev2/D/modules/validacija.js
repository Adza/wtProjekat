var Validacija = (function() {
  var maxGrupa = 7;
  var trenutniSemestar = 0; //0 za zimski, 1 za ljetni semestar
  return {
    validirajFakultetski: function() {},
    validirajIndex: function(brIndexa) {
      return /^1\d{4}$/.test(brIndexa);
    },
    validirajGrupu: function(grupa) {
      return (grupa <= maxGrupa && grupa>=1)
    },
    validirajAkGod: function() {},
    validirajPassword: function(password) {
      return /((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,20})/.test(password);
    },
    validirajPotvrdu: function(password, confirmation) {
      return password === confirmation;
    },
    validirajBitbucketURL: function() {},
    validirajBitbucketSSH: function() {},
    validirajNazivRepozitorija: function() {},
    validirajImeiPrezime: function() {},
    validirajSemestar: function(semestar){
      return (semestar===1 || semestar===0)
    },
    postaviMaxGrupa: function(novaMaxGrupa) {
      maxGrupa = novaMaxGrupa;
    },
    postaviTrenSemestar: function(trenSemestar) {
      trenutniSemestar = trenSemestar;
    }
  }
}());
