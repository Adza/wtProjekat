var prikaziStudenta = function() {
  document.getElementById("registrujNastavnika").style.display = 'none';
  document.getElementById("registrujStudenta").style.display = 'flex';
}
var prikaziNastavnika = function() {
  document.getElementById("registrujNastavnika").style.display = 'flex';
  document.getElementById("registrujStudenta").style.display = 'none';
}

var validacija = Validacija;
var poruke = Poruke;
poruke.postaviIdDiva("greske");
var korisnickoIme = document.getElementsByClassName('korisnickoIme');
var password = document.getElementsByClassName('password');
var confirmPassword = document.getElementsByClassName('confirmPassword');
var email = document.getElementsByClassName('email');
var maxBrojGrupa = document.getElementsByClassName('maxBrojGrupa');
var regexRepo = document.getElementsByClassName('regexRepo');
var trenutniSemestar = document.getElementsByClassName('trenutniSemestar');
var akademskaGodina = document.getElementsByClassName('akademskaGodina');
var brojIndeksa = document.getElementsByClassName('brojIndeksa');
var imePrezime = document.getElementsByClassName('imePrezime');
var brojIndeksa = document.getElementsByClassName('brojIndeksa');
var bitbucketURL = document.getElementsByClassName('bitbucketURL');
var bitbucketSSH = document.getElementsByClassName('bitbucketSSH');
var nazivRepo = document.getElementsByClassName('nazivRepo');
var nastavnaGrupa = document.getElementsByClassName('nastavnaGrupa');
for (i = 0; i < korisnickoIme.length; i++) {
  var input = korisnickoIme[i];
  input.onblur = function() {}
}

for (i = 0; i < nastavnaGrupa.length; i++) {
  var input = nastavnaGrupa[i];
  input.onblur = function() {
    var validationResult = validacija.validirajGrupu(this.options[this.selectedIndex].value);
    if (validationResult) {
      poruke.ocistiGresku(3);
    } else {
      poruke.dodajPoruku(3);
    }
    poruke.ispisiGreske();
  }
}
//done
for (i = 0; i < password.length; i++) {
  var input = password[i];
  input.onblur = function() {
    var validationResult = validacija.validirajPassword(this.value);
    if (validationResult) {
      poruke.ocistiGresku(6);
    } else {
      poruke.dodajPoruku(6);
    }
    poruke.ispisiGreske();
  }
}

//done
for (i = 0; i < confirmPassword.length; i++) {
  var input = confirmPassword[i];
  input.onblur = function() {
    var validationResult = validacija.validirajPotvrdu(password[i].value, this.value);
    if (validationResult) {
      poruke.ocistiGresku(7);
    } else {
      poruke.dodajPoruku(7);
    }
    poruke.ispisiGreske();
  }
}
//half
for (i = 0; i < email.length; i++) {
  var input = email[i];
  input.onblur = function() {
    var validationResult = validacija.validirajFakultetski(this.value);
    if (validationResult) {
      poruke.ocistiGresku(1);
    } else {
      poruke.dodajPoruku(1);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < trenutniSemestar.length; i++) {
  var input = trenutniSemestar[i];
  input.onblur = function() {
    var validationResult = validacija.validirajTrenSemestar(this.value);
    if (validationResult) {
      poruke.ocistiGresku(4);
    } else {
      poruke.dodajPoruku(4);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < akademskaGodina.length; i++) {
  var input = akademskaGodina[i];
  input.onblur = function() {
    var validationResult = validacija.validirajAkGod(this.value);
    if (validationResult) {
      poruke.ocistiGresku(5);
    } else {
      poruke.dodajPoruku(5);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < imePrezime.length; i++) {
  var input = imePrezime[i];
  input.onblur = function() {
    var validationResult = validacija.validirajImePrezime(this.value);
    if (validationResult) {
      poruke.ocistiGresku(11);
    } else {
      poruke.dodajPoruku(11);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < brojIndeksa.length; i++) {
  var input = brojIndeksa[i];
  input.onblur = function() {
    var validationResult = validacija.validirajIndex(this.value);
    if (validationResult) {
      poruke.ocistiGresku(2);
    } else {
      poruke.dodajPoruku(2);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < bitbucketURL.length; i++) {
  var input = bitbucketURL[i];
  input.onblur = function() {
    var validationResult = validacija.validirajBitbucketURL(this.value);
    if (validationResult) {
      poruke.ocistiGresku(8);
    } else {
      poruke.dodajPoruku(8);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < bitbucketSSH.length; i++) {
  var input = bitbucketSSH[i];
  input.onblur = function() {
    var validationResult = validacija.validirajBitbucketSSH(this.value);
    if (validationResult) {
      poruke.ocistiGresku(9);
    } else {
      poruke.dodajPoruku(9);
    }
    poruke.ispisiGreske();
  }
}

for (i = 0; i < nazivRepo.length; i++) {
  var input = nazivRepo[i];
  input.onblur = function() {
    var validationResult = validacija.validirajNazivRepozitorija(this.value);
    if (validationResult) {
      poruke.ocistiGresku(10);
    } else {
      poruke.dodajPoruku(10);
    }
    poruke.ispisiGreske();
  }
}
