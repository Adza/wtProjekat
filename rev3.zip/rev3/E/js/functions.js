// Funkcija za prikaz formi za registraciju
function showRegistrationForm(form_id) {
    var greske = document.getElementById('greske');
    greske.innerHTML = "";
    document.getElementById('form-nastavnik-registration').reset();
    document.getElementById('form-student-registration').reset();
    ocistiSveGreske();
    if(form_id == "form-nastavnik-registration") {
        document.getElementById('form-nastavnik-registration').style.display = "block";
        document.getElementById('form-student-registration').style.display = "none";
    }
    else {
        document.getElementById('form-nastavnik-registration').style.display = "none";
        document.getElementById('form-student-registration').style.display = "block";
    }
}

// Funkcija za dohvaćanje sadržaja stranice 'pageName'
function getPageContent(pageName) {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200)
            document.getElementById('container').innerHTML = ajax.responseText;
        if(ajax.readyState == 4 && ajax.status == 404)
            document.getElementById('container').innerHTML = 'Greška: Nepoznat URL!';
    }

    ajax.open('GET', pageName, true);
    ajax.send();
}

// Funkcija za kreiranje spiska za 4. zadatak
function kreirajSpisak() {
    var ajax = new XMLHttpRequest();

    ajax.onreadystatechange = function() {
        if(ajax.readyState == 4 && ajax.status == 200) {
            document.getElementById('odgovor').innerHTML = JSON.parse(ajax.responseText)['message'];
        }
        if(ajax.readyState == 4 && ajax.status == 404)
            document.getElementById('odgovor').innerHTML = '404';
    }

    var brojSpirale = document.getElementById('broj-spirale').value;
    var textAreaLines = document.getElementById('textarea').value.split('\n'); // Predstavlja niz čiji su elementi linije
    var json = kreirajJSON(brojSpirale, textAreaLines);

    ajax.open('POST', 'http://localhost:3000/spisak', true);
    ajax.setRequestHeader('Content-Type', 'application/json');
    ajax.send(json);
}

// Pomoćna funkcija za kreiranje json-a (stringa koji ima format json-a)
function kreirajJSON(brojSpirale, textAreaLines) {
    if(textAreaLines.length != 0)
        var json = '[[' + brojSpirale + '],';
    else {
        var json = '[[' + brojSpirale + ']]';
        return json;
    }

    for(var i = 0; i < textAreaLines.length; i++) {
        var line = textAreaLines[i].split(','); // Predstavlja niz čiji su elementi indexi i-te linije
        
        json += '[';
        for(var j = 0; j < line.length; j++) {
            if(j != line.length - 1)
                json += '\"' + line[j] + '"\,';
            else
                json += '\"' + line[j] + '"\]'; // Kraj i-tog niza
        }

        if(i != textAreaLines.length - 1)
            json += ',';
    }

    json += ']';
    return json;
}

// Funkcija za kreiranje izvjestaja (5. zadatak pod d))
function generisiIzvjestaj() {
    var spirala = document.getElementById('broj-spirale').value;
    var index = document.getElementById('broj-indeksa').value;

    KreirajFajl.kreirajIzvjestaj(spirala, index, (error, data) => {
        console.log(JSON.parse(data)['message']);
    })
}

// Funkcija za generisanje bodova (5. zadatak pod d))
function generisiBodove() {
    var spirala = document.getElementById('broj-spirale').value;
    var index = document.getElementById('broj-indeksa').value;

    KreirajFajl.kreirajBodove(spirala, index, (error, data) => {
        document.getElementById('poruka').innerHTML = JSON.parse(data)['poruka'];
    });
}

// Funkcija za generisanje komentara
function generisiKomentare() {
    var spirala = document.getElementById('broj-spirale').value;
    var index = document.getElementById('broj-indeksa').value;
    var tabela = document.getElementById('tabela-studenti');

    var jsonSadrzaj = '[';
    for(var i = 1; i < tabela.rows.length; i++) {
        jsonSadrzaj += '{';
        jsonSadrzaj += '\"sifra_studenta\": ' + '\"' + tabela.rows[i].cells[0].children[0].value + '\",';
        jsonSadrzaj += '\"tekst\": ' + '\"' + tabela.rows[i].cells[1].children[0].value + '\",';
        jsonSadrzaj += '\"ocjena\": ' + i + ' }';
        if(i != tabela.rows.length - 1)
            jsonSadrzaj += ',';
    }
    jsonSadrzaj += ']';

    jsonSadrzaj = JSON.parse(jsonSadrzaj);
    
    KreirajFajl.kreirajKomentar(spirala, index, jsonSadrzaj, (error, data) => {
        console.log(data);
    })
}

// Funkcija za generisanje liste
function generisiListu() {
    var key = document.getElementById('key').value;
    var secret = document.getElementById('secret').value;
    var repozitorij = document.getElementById('repozitorij').value;
    var branch = document.getElementById('branch').value;
    var godina = document.getElementById('godina').value;
    
    BitbucketApi.dohvatiAccessToken(key, secret, function(error, token) {
        BitbucketApi.dohvatiRepozitorije(token, godina, repozitorij, branch, function(error, nizRepozitorija) {
            KreirajFajl.kreirajListu(godina, nizRepozitorija, (error, msg) => {
                document.getElementById('poruka').innerHTML = JSON.parse(msg)['message'] + ' sa ' + JSON.parse(msg)['data'] + ' repozitorija';
            });
        });
    });
}
