var KreirajFajl = (function(){
    return {
        kreirajKomentar: function(spirala, index, sadrzaj, fnCallback) {
            // Provjeravamo parametre
            var validniParametri = true;
            if(spirala.length < 1 || index.length < 1)
                validniParametri = false;

            for(var i = 0; i < sadrzaj.length; i++) {
                if(!('sifra_studenta' in sadrzaj[i]) || !('tekst' in sadrzaj[i]) || !('ocjena' in sadrzaj[i])) {
                    validniParametri = false;
                    break;
                }
            }
            
            if(validniParametri == false) { // Paramteri nisu ispravni, pozivamo fnCallback
                fnCallback(-1, 'Neispravni paramteri');
            }
            else { // Ukoliko su paramteri ispravni, nastavljamo sa slanjem ajax request-a
                var ajax = new XMLHttpRequest();

                ajax.onreadystatechange = function() {
                    if(ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, ajax.responseText);
                    if(ajax.readyState == 4 && ajax.status == 404)
                        fnCallback(ajax.status, ajax.responseText);
                }

                var json = JSON.stringify(
                    {
                        spirala: spirala,
                        index: index,
                        sadrzaj: sadrzaj
                    }
                );
            
                ajax.open('POST', 'http://localhost:3000/komentar', true);
                ajax.setRequestHeader('Content-Type', 'application/json');
                ajax.send(json);
            }
        },
        kreirajListu: function(godina, nizRepozitorija, fnCallback) {
            // Provjeravamo paramtre
            var validniParametri = true;
            if(godina.length < 1 || nizRepozitorija.length < 1)
                validniParametri = false;
            
            if(validniParametri == false) { // Paramteri nisu ispravni, pozivamo fnCallback
                fnCallback(-1, 'Neispravni parametri');
            }
            else { // Ukoliko su paramteri ispravni, nastavljamo sa slanjem ajax request-a
                var ajax = new XMLHttpRequest();

                ajax.onreadystatechange = function() {
                    if(ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, ajax.responseText);
                    if(ajax.readyState == 4 && ajax.status == 404)
                        fnCallback(ajax.status, ajax.responseText);
                }

                var json = JSON.stringify(
                    {
                        godina: godina,
                        nizRepozitorija: nizRepozitorija
                    }
                );

                ajax.open('POST', 'http://localhost:3000/lista', true);
                ajax.setRequestHeader('Content-Type', 'application/json');
                ajax.send(json);
            }
        },
        kreirajIzvjestaj: function(spirala, index, fnCallback) {
            // Provjeravamo parametre
            var validniParametri = true;
            if(index.length < 1)
                validniParametri = false;

            if(validniParametri == false) { // Paramteri nisu ispravni, pozivamo fnCallback
                fnCallback(-1, 'Neispravni parametri');
            }
            else { // Ukoliko su paramteri ispravni, nastavljamo sa slanjem ajax request-a
                var ajax = new XMLHttpRequest();

                ajax.onreadystatechange = function() {
                    if(ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, ajax.responseText);
                    if(ajax.readyState == 4 && ajax.status == 404)
                        fnCallback(ajax.status, ajax.responseText);
                }
            
                var json = JSON.stringify(
                    {
                        spirala: spirala,
                        index: index
                    }
                );

                ajax.open('POST', 'http://localhost:3000/izvjestaj', true);
                ajax.setRequestHeader('Content-Type', 'application/json');
                ajax.send(json);
            }
        },
        kreirajBodove: function(spirala, index, fnCallback) {
            // Provjeravamo parametre
            var validniParametri = true;
            if(index.length < 1)
                validniParametri = false;

            if(validniParametri == false) { // Paramteri nisu ispravni, pozivamo fnCallback
                fnCallback(-1, 'Neispravni parametri');
            }
            else { // Ukoliko su paramteri ispravni, nastavljamo sa slanjem ajax request-a
                var ajax = new XMLHttpRequest();

                ajax.onreadystatechange = function() {
                    if(ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, ajax.responseText);
                    if(ajax.readyState == 4 && ajax.status == 404)
                        fnCallback(ajax.status, ajax.responseText);
                }
            
                var json = JSON.stringify(
                    {
                        spirala: spirala,
                        index: index
                    }
                );

                ajax.open('POST', 'http://localhost:3000/bodovi', true);
                ajax.setRequestHeader('Content-Type', 'application/json');
                ajax.send(json);
            }
        }
    }
})();