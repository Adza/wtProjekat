var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var app = express();
var serverModul = require('../js/serverModul');

app.use(bodyParser.json());
app.use(express.static('html'));
app.use(express.static('./')); // root

app.get('/', (request, response) => {
    response.sendFile(__dirname + 'index.html');
});

app.post('/spisak', (request, response) => {   
    var json = request.body;

    // Validiramo json
    serverModul.serverValidacija().validirajJSONZaSpisak(json, (error, index) => { // index predstavlja indeks prvog reda koji ima duple indekse, ili -1 ako takvih nema
        if(index != -1) {
            response.send({
                'message': 'U redu ' + index + '. se nalaze dupli indexi!'
            });
        }
        else {
            // U prvom nizu imamo samo jedan element - broj spirale
            var path = __dirname + '/spisakS' + json[0][0] + '.json';
            
            // Kreiramo novi json bez prvog elementa, i oko svakog elementa stavljamo navodnike       
            jsonString = '[';
            for(var i = 1; i < json.length; i++) {
                jsonString += '[';
                for(var j = 0; j < json[i].length; j++) {
                    if(j != json[i].length - 1)
                        jsonString += '\"' + json[i][j] + '\",';
                    else
                        jsonString += '\"' + json[i][j] + "\"";
                }
                if(i != json.length - 1)
                    jsonString += '],'
                else
                    jsonString += ']';
            }       
            jsonString += ']';

            fs.appendFile(path, jsonString, (error) => {
                response.send({
                    'message': 'Uspješno upisano u datoteku!'
                })
            })
        }
    });
});

app.post('/komentar', (request, response) => {
    var json = request.body;
    var validniPodaci = serverModul.serverValidacija().validirajPodatkeZaKomentar(json);

    if(validniPodaci == false) {
        response.status(400);
        response.send({
            'message': 'Podaci nisu u traženom formatu!',
            'data': null
        });
    }
    else {
        var path = __dirname + '/markS' + json['spirala'] + json['index'] + '.json';
        // Kreiramo datoteku u koju upisujemo sadržaj
        fs.writeFile(path, JSON.stringify(json['sadrzaj']), (error) => {
            if(error) {
                console.log(error);
                throw error;
            }
        })
        response.send({
            'message': 'Uspješno kreirana datoteka',
            'data': json['sadrzaj']
        });
    }
});

app.post('/lista', (request, response) => {
    var json = request.body;
    var validniPodaci = serverModul.serverValidacija().validirajPodatkeZaListu(json);
    console.log(validniPodaci);
    if(validniPodaci == false) {
        response.status(400);
        response.send({
            'message': 'Podaci nisu u traženom formatu!',
            'data': null
        });
    }
    else {
        var path = __dirname + '/spisak' + json['godina'] + '.txt';
        // Provjerimo koliko ćemo dodati ukupno repozitorija u datoteku
        var brojValidnihRepozitorija = 0; // Validan repozitorij smatramo onim koji ima json['godina'] u nazivu (linku)
        for(var i = 0; i < json['nizRepozitorija'].length; i++) {
            if(json['nizRepozitorija'][i].indexOf(json['godina']) != -1)
                brojValidnihRepozitorija++;
        }
        
        // Prolazimo kroz niz linkova, te upisujemo samo one koji sadrže godinu jednaku json['godina']
        var counter = 0; // counter se mora izvršiti onoliko puta kolika je vrijednost brojValdnihRepozitorija
        for(var i = 0; i < json['nizRepozitorija'].length; i++) {
            if(json['nizRepozitorija'][i].indexOf(json['godina']) != -1) {
                // Kreiramo ssh na osnovu http linka iz niza
                var array = json['nizRepozitorija'][i].split('/');
                var ssh = json['nizRepozitorija'][i];
                
                fs.appendFile(path, ssh + '\n', (error) => {
                    if(error) throw error;
                    counter++;
                    if(counter == brojValidnihRepozitorija) // Šaljemo response
                        response.send({
                            'message': 'Lista uspješno kreirana',
                            'data': brojValidnihRepozitorija
                        });
                })
            }
        }
    }
});

app.post('/izvjestaj', (request, response) => {
    var json = request.body; // Predstavlja json { "spirala": vrijednost, "index": vrijednost }
    var nazivDatoteke = 'spisakS' + json['spirala'] + '.json';

    fs.readdir(__dirname, (error, files) => {
        var postojiDatoteka = false;
        for(var i = 0; i < files.length; i++) {
            if(files[i] == nazivDatoteke) {
                postojiDatoteka = true;
                break;
            }
        }

        if(postojiDatoteka == false) {
            response.send({
                'message': 'Datoteka ne postoji!' 
            });
        }
        else {
            fs.readFile(__dirname + '/' + nazivDatoteke, 'utf-8', (error, spisak) => {
                if(error) throw error;
                
                spisak = JSON.parse(spisak);
                var sifre = ['', 'A', 'B', 'C', 'D', 'E'];
                var komentari = "";
                var counter = 0;

                spisak.forEach(function(array, i) {
                    array.forEach(function(arrayItem, j) {
                        console.log('usao');
                        if(arrayItem == json['index']) {
                            path = __dirname + '/markS' + json['spirala'] + (spisak[i])[0] + '.json';
                            
                            fs.readFile(path, 'utf-8', (err, data) => {
                                counter++;
                                console.log(counter);

                                data = JSON.parse(data);
                                for(var k = 0; k < data.length; k++)
                                    if((data[k])['sifra_studenta'] == sifre[j]) {
                                        if(counter != 5) 
                                            komentari += (data[k])['tekst'] + '\n##########\n';
                                        else 
                                            komentari += (data[k])['tekst'];
                                    }
                                    
                                if(counter == 5) { // Komentari su spremni da se upišu u datoteku izvjestaj
                                    console.log('hehehe');
                                    var izvjestajPath = __dirname + '/izvjestajS' + json['spirala'] + json['index'] + '.txt';
                                    fs.writeFile(izvjestajPath, komentari, (error) => {
                                        if(error) throw error;
                                        
                                        response.send({
                                            'message': 'Komentari uspješno upisani u datoteku!'
                                        });
                                    });
                                }
                            })
                        }
                    }); 
                });
            })
        }
    });
});

app.post('/bodovi', (request, response) => {
    var json = request.body;
    var nazivDatoteke = 'spisakS' + json['spirala'] + '.json';
    var brojBodova = 0;

    fs.readFile(__dirname + '/' + nazivDatoteke, 'utf-8', (error, spisak) => {
        if(error) throw error;
        
        spisak = JSON.parse(spisak);
        var sifre = ['', 'A', 'B', 'C', 'D', 'E'];
        var brojBodova = 0;
        var counter = 0;

        spisak.forEach(function(array, i) {
            array.forEach(function(arrayItem, j) {
                if(arrayItem == json['index']) {
                    path = __dirname + '/markS' + json['spirala'] + (spisak[i])[0] + '.json';
                    
                    fs.readFile(path, 'utf-8', (err, data) => {
                        counter++;
                        data = JSON.parse(data);
                        for(var k = 0; k < data.length; k++)
                            if((data[k])['sifra_studenta'] == sifre[j]) {
                                    brojBodova += (data[k])['ocjena'];
                            }

                        if(counter == 5) { // Sabrali smo sve ocjene, vracamo prosjecno mjesto
                            if(brojBodova / 5 - Math.floor(brojBodova / 5) != 0) 
                                var prosjecnoMjesto = Math.floor(brojBodova / 5) + 1;
                            else
                            var prosjecnoMjesto = brojBodova / 5;
                            response.send({
                                'poruka': 'Student ' + json['index'] + ' je ostvario u prosjeku ' + prosjecnoMjesto + ' mjesto'
                            });
                        }
                    })
                }
            }); 
        });
    })
});
app.listen(3000);