exports.serverValidacija = (function() {
    return {
        validirajPodatkeZaKomentar: function(json) {
            if(!('spirala' in json) || !('index' in json) || !('sadrzaj' in json))
                return false;
            if(json['spirala'].length < 1 || json['index'].length < 1)
                return false;

                // provjerimo da li svaki objekat niza sadrzaj ima atribute: sifra_studenta, tekst, ocjena
            for(var i = 0; i < json['sadrzaj'].length; i++)
                if(!('sifra_studenta' in json['sadrzaj'][i]) || !('tekst' in json['sadrzaj'][i]) || !('ocjena' in json['sadrzaj'][i]))
                    return false;
            
            return true;
        },
        validirajPodatkeZaListu: function(json) {
            if(!('godina' in json) || !('nizRepozitorija' in json))
                return false;
            
            return true;
        },
        validirajJSONZaSpisak: async function(json, fnCallback) {
            for(var i = 0; i < json.length; i++) {
                var array = json[i];
                var index = -1;

                for(var j = 0; j < json[i].length - 1; j++) {
                    var element = json[i][j];
                    for(var k = j + 1; k < json[i].length; k++)
                        if(json[i][j] == json[i][k]) {
                            index = i;
                            break;
                        }
                    if(index != -1) break;
                }

                if(index != -1) break;
            }

            fnCallback(null, index); 
        }
    }
});