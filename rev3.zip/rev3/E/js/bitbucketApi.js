var BitbucketApi = (function() {
    return {
        dohvatiAccessToken: function(key, secret, fnCallback) {
            if(key == null || secret == null) // Parametri nisu ispravno proslijeđeni, pozivamo callback
                fnCallback(-1, 'Key ili secret nisu pravilno proslijeđeni!');
            else { // Ispravni paramteri, nastavljamo sa slanjem ajax request-a
                var ajax = new XMLHttpRequest();

                ajax.onreadystatechange = function() {
                    if(ajax.readyState == 4 && ajax.status == 200)
                        fnCallback(null, JSON.parse(ajax.responseText).access_token)
                    else if(ajax.readyState == 4)
                        fnCallback(ajax.status, ajax.responseText);
                }

                ajax.open('POST', 'https://bitbucket.org/site/oauth2/access_token', true);
                ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                // Bilo prije Buffer.from(key + ':' + secret).toString('base64'), pa javljalo grešku
                ajax.setRequestHeader('Authorization', 'Basic ' + btoa(key + ':' + secret));
                ajax.send('grant_type=' + encodeURIComponent('client_credentials'));
            }
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback) {
            var ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function() {
                if(ajax.readyState == 4 && ajax.status == 200) {
                    if(JSON.parse(ajax.responseText).values.length == 0) // prazan odgovor
                        fnCallback(null, null);
                    else {
                        var counter = 0; // Koristimo da bi znali koliko se asinhronih funkcija izvršilo
                        var listaRepozitorija = [];
                        var json = JSON.parse(ajax.responseText);

                        // Popunjavamo listu repozitorija samo sa repozitorijima koji imaju branch takav da mu je naziv jednak vrijednosti parametra 'branch'
                        json.values.forEach(function(jsonObject, index) {
                            BitbucketApi.dohvatiBranch(token, json.values[index].links.branches.href, branch, function(error, data) {
                                if(data == true)
                                    listaRepozitorija.push(json.values[index].links.clone[1].href);
                                if(counter == json.values.length - 1) // Sve asinhrone funkcije su pozvane
                                    fnCallback(null, listaRepozitorija);

                                counter++;
                            });
                        });
                    }
                }
                else if(ajax.readyState == 4)
                    fnCallback(ajax.status, null);
            }
            
            var datum1 = godina + "-01-01T00:00:00.000Z";
            godina = Number(godina) + 2;
            var datum2 = godina + "-01-01T00:00:00.000Z";

            ajax.open('GET', 'https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150&q=name~"' 
                + naziv + '" and created_on > "' + datum1 + '" and created_on < "' + datum2 + '"', true);
            console.log('https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150&q=name~"' 
            + naziv + '" and created_on > "' + datum1 + '" and created_on < "' + datum2 + '"');
            ajax.setRequestHeader('Authorization', 'Bearer ' + token);
            ajax.send();
        },
        dohvatiBranch: function(token, url, naziv, fnCallback) {
            var ajax = new XMLHttpRequest();

            ajax.onreadystatechange = function() {
                if(ajax.readyState == 4 && ajax.status == 200) {
                    if(JSON.parse(ajax.responseText).values.length != 0)
                        fnCallback(null, true);
                    else
                        fnCallback(null, false);
                }              
                else if(ajax.readyState == 4)
                    fnCallback(ajax.status, null);
            }

            ajax.open('GET', url + '?q=name="' + naziv + '"', true);
            ajax.setRequestHeader('Authorization', 'Bearer ' + token);
            ajax.send();
        }
    }
})();

/*
Kod koji je koristen za testiranje, mijenjati parametre unutar BitbucketApi.dohvatiRepozitorije za dobijanje različitih rezultata
var XMLHttpRequest = require('xhr2');
BitbucketApi.dohvatiAccessToken('3ap7U3LaCRg74QpPmS', 'zLaRTSeF4Rj7wjD57mHFg9uAUQcysyJ8', function(error, data) {
    BitbucketApi.dohvatiRepozitorije(data, 2016, '', 'master', function(error, data) {
        for(var i = 0; i < data.length; i++)
            console.log(data[i]);
    });
});
*/