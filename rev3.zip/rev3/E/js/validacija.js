var Validacija = (function() {
    var maxGrupa = 7;
    var trenutniSemestar = 0;
    var poruke = Poruke();
    var validan_input;
    return { 
        validirajFakultetski: function(email) {
            var regex = /^[a-zA-Z0-9._]+@etf\.unsa\.ba$/;
            validan_input = regex.test(email);

            azurirajDivZaGreske(validan_input, poruke, "greske", 0);
        },
        validirajIndex: function(index) {
            var regex = /^[1][0-9]{4}$/;
            validan_input = regex.test(index);

            azurirajDivZaGreske(validan_input, poruke, "greske", 1);
        },
        validirajGrupu: function(broj_grupe) {
            validan_input = broj_grupe >= 1 && broj_grupe <= maxGrupa ? true : false;
            
            azurirajDivZaGreske(validan_input, poruke, "greske", 2);
        },
        validirajAkGod: function(string) {
            var zimski_semestar_godina = string.split('/')[0];
            var ljetni_semestar_godina = string.split('/')[1];
            var trenutna_godina = (new Date).getFullYear();
            
            validan_input = (trenutniSemestar == 0 && zimski_semestar_godina == trenutna_godina && zimski_semestar_godina == ljetni_semestar_godina - 1
            || trenutniSemestar == 1 && ljetni_semestar_godina == trenutna_godina && ljetni_semestar_godina == zimski_semestar_godina + 1) ? 
            true : false;
            
            azurirajDivZaGreske(validan_input, poruke, "greske", 3);
        },
        validirajPassword: function(password) {
            var regex = /^(?=[A-Z]\w*)(?=.*\d)[A-Za-z\d]{7,20}$/;
            validan_input = regex.test(password);
            
            azurirajDivZaGreske(validan_input, poruke, "greske", 4);    
        },
        validirajPotvrdu: function(potvrda1_sifra, potvrda2_sifra) {
            validan_input = potvrda1_sifra == potvrda2_sifra ? true : false;

            azurirajDivZaGreske(validan_input, poruke, "greske", 5);
        },
        validirajBitbucketURL: function(url) {
            // A valid username must be non-empty, and contain only letters, numbers, underscores, or hyphens...
            // Repository name može imati najviše 255 karaktera, pri čemu naziv repozitorija ne može biti . (možda ima još ograničenja)...
            var regex = /^https:\/\/[A-Za-z0-9_]+@bitbucket.org\/[A-Za-z0-9_]+\/(\.)?[A-Za-z0-9_čćžšđ_]+\.git$/;
            validan_input = regex.test(url);

            azurirajDivZaGreske(validan_input, poruke, "greske", 6);
        },
        validirajBitbucketSSH: function(ssh_adresa) {
            var regex = /^git@bitbucket\.org:[A-Za-z0-9_]+\/(\.)?[A-Za-z0-9_čćžšđ_]+\.git$/     
            validan_input = regex.test(ssh_adresa);
            
            azurirajDivZaGreske(validan_input, poruke, "greske", 7);
        }, 
        validirajNazivRepozitorija: function(regex_naziv) {
            var reg = regex_naziv.split('/')[1];
            var naziv = regex_naziv.split('/')[2];
                   
            if(reg == null) {
                naziv = regex_naziv;
                reg = /^wt[Pp]rojekat1[0-9]{4}$/;
            }
            else {
                reg = new RegExp(reg);
            }

            validan_input = reg.test(naziv);
            
            azurirajDivZaGreske(validan_input, poruke, "greske", 8);
        },
        validirajImeiPrezime: function(string) {
            var regex1 = /^(\b[A-Z][-'A-Za-zČĆŽŠĐčćžšđ]*\s*)+$/;
            var regex2 = /\w{3,12}/          
            validan_input = regex1.test(string) && regex2.test(string);

            azurirajDivZaGreske(validan_input, poruke, "greske", 9);
        },
        postaviMaxGrupa: function(max_grupa) {
            maxGrupa = max_grupa;
        },
        postaviTrenSemestar: function() {
            var trenutni_semestar = document.getElementById("nastavnik-trenutni-semestar");
            trenutni_semestar = trenutni_semestar.options[trenutni_semestar.selectedIndex].text;           
            trenutniSemestar = trenutni_semestar;
        }
    }
});

function azurirajDivZaGreske(validan_input, poruke, div_id, broj_poruke) {
    if(validan_input == false) {
        poruke.postaviIdDiva('greske');
        poruke.dodajPoruku(broj_poruke);
    }
    else {
        poruke.ocistiGresku(broj_poruke);
    }
    poruke.ispisiGreske();
}

var validacija = Validacija();

function ocistiSveGreske() { // ova funkcija se poziva iz funkcije.js kada se učitaje nova forma, tako da resetujemo prethodnu validaciju (u suprotnom bi postojale greške od validacije sa prethodne forme)
    validacija = Validacija();
}