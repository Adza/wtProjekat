Poruke = (function() {
    var idDivaPoruka;
    var mogucePoruke=["Email koji ste unijeli nije validan fakultetski email!",
                        "Indeks kojeg ste unijeli nije validan!",
                        "Nastavna grupa koju ste unijeli nije validna!",
                        "Akademska godina koju ste unijeli nije validna!",
                        "Password koji ste unijeli nije validan!",
                        "Potvrda passworda koju ste unijeli nije validna!",
                        "Bitbucket URL koji ste unijeli nije validan!",
                        "Bitbucket SSH koji ste unijeli nije validan!",
                        "Naziv repozitorija koji ste unijeli nije validan!",
                        "Ime i prezime koje ste unijeli nije validno!"];
    var porukeZaIspis=[];
    return {
        ispisiGreske: function() {
            var greske = document.getElementById('greske');
            greske.innerHTML = "";
            for(i = 0; i < porukeZaIspis.length; i++) {
                if(porukeZaIspis[i] != "") {
                    greske.innerHTML += "<br/>" + porukeZaIspis[i];                    
                }
            }
        },
        postaviIdDiva: function(div_id) {
            idDivaPoruka = div_id;
        },
        dodajPoruku: function(broj_poruke) {
            function postoji(arr,obj) {
                return (arr.indexOf(obj) != -1);
            }

            if(postoji(porukeZaIspis, mogucePoruke[broj_poruke]) == false) {
                porukeZaIspis.push(mogucePoruke[broj_poruke]);
            }          
        },
        ocistiGresku: function(broj_poruke) {
            for(i = 0; i < porukeZaIspis.length; i++) {
                if(porukeZaIspis[i] == mogucePoruke[broj_poruke]) {
                    porukeZaIspis[i] = "";
                }           
            }
        }
    }
});