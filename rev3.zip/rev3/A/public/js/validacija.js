var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar

var validirajFakultetski=function(email) 
{
	var EmailRegEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@etf.unsa.ba$/g;
	if (!EmailRegEx.test (email) ){
		return false;
	}
	return true ;
}

var validirajIndex=function(indeks){
	var indeksRegEx = /^1\d{4}$/g;
	if(!indeksRegEx.test(indeks)){
		return false;
	}
	return true;
}
var validirajGrupu=function(grupa){
	if(grupa < 1 || grupa>maxGrupa)
		return false;
	return true;	
}
var validirajAkGod = function(godina){
	var godine = godina.split('/');
	if(godine.length != 2)
		return false;
	//ako u datumu nisu brojevi
	if(parseInt(godine[0]) == null || parseInt(godine[1]) == null)
		return false;
	var prvagodina = parseInt(godine[0]);
	var drugagodina = parseInt(godine[1]);
	// Ako prve dvije cifre nisu 20 vrati false
	if(prvagodina < 2000 || prvagodina > 2099  || drugagodina < 2000 || drugagodina > 2099)
		return false;
	
	if(prvagodina + 1 != drugagodina)
		return false;
	
	return true;
}

var validirajPassword= function(pass){
	var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,20}$/g; 
	if(!passw.test(pass))     
		return false;  
	return true;  
}
var validirajPotvrdu= function(a, b){
	if( a !== b)
		return false;
	return true;
}
var validirajImeiPrezime= function( imePrezime ){
	var reg=/^[a-zA-ZčćđšžČČĐŠŽ '-]+$/g;
	if(!reg.test(imePrezime))
		return false;
	return true;
	
}
var validirajBitbucketURL = function(bitbucketurl){
	var reg=/^https:\/\/[\w]*@bitbucket\.org\/[\w]*\/[\w]*\.git$/g;
	if(!reg.test(bitbucketurl)){
		return false;
	}
	return true;
}
var validirajBitbucketSSH = function(bitbucketssh){
	var reg=/^git@bitbucket\.org:[\w]*\/[\w]*\.git$/g;
	if(!reg.test(bitbucketssh)){
		return false;
	}
	return true;
}
var validirajNazivRepozitorija = function(regex,nazivrepozitorija){
	var reg=/^wt[Pp]rojekat1\d{4}$/g;
	var mregex=new RegExp(regex);
	if(mregex == null){
		if(!reg.test(nazivrepozitorija)){
			return false;
		}
		return true;
	} else {
		if(!mregex.test(nazivrepozitorija)){
			return false;
		}
		return true;
	}
}
var postaviMaxGrupa  = function(_maxGrupa){
	if(_maxGrupa < 1) 
		return false;
	else{
		maxGrupa = _maxGrupa;
		return true;
	}
}
var postaviTrenSemestar = function(_trenutniSemestar){
	if(_trenutniSemestar == 0 || _trenutniSemestar == 1){
		trenutniSemestar = _trenutniSemestar;
		return true;
		
	}
	else{
		return false;
	}
}
return{
	validirajFakultetski: validirajFakultetski,
	validirajIndex: validirajIndex,
	validirajGrupu: validirajGrupu, 
	validirajAkGod: validirajAkGod,
	validirajPassword: validirajPassword, 
	validirajPotvrdu: validirajPotvrdu,
	validirajBitbucketURL: validirajBitbucketURL ,
	validirajBitbucketSSH: validirajBitbucketSSH,
	validirajNazivRepozitorija: validirajNazivRepozitorija,
	validirajImeiPrezime: validirajImeiPrezime,
	postaviMaxGrupa: postaviMaxGrupa,
	postaviTrenSemestar: postaviTrenSemestar
}
}());