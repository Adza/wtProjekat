window.onload = function () {
	document.getElementById('registracijaNastavnika').style.display='none';
	document.getElementById('registracijaStudenta').style.display='inline';
}


function funkcijaRegistrujStudenta(){
	document.getElementById('registracijaNastavnika').style.display='none';
	document.getElementById('registracijaStudenta').style.display='inline';
	var greske = document.getElementById('greske');
	greske.innerHTML = "";
}


function funkcijaRegistrujNastavnika(){
	document.getElementById('registracijaNastavnika').style.display='inline';
	document.getElementById('registracijaStudenta').style.display='none';
	var greske = document.getElementById('greske');
	greske.innerHTML = "";

}

var faxemailN = document.getElementById("faxemailN");
faxemailN.addEventListener( "focusout", function(){ 
	if(Validacija.validirajFakultetski(faxemailN.value) == false){
		Poruke.dodajPoruku(0);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(0);
		Poruke.ispisiGreske();		
	}
});


var imePrezimeS = document.getElementById("imePrezimeS");
imePrezimeS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajImeiPrezime(imePrezimeS.value) == false){
		Poruke.dodajPoruku(1);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(1);
		Poruke.ispisiGreske();		
	}
});

var indeksS = document.getElementById("indeksS");
indeksS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajIndex(indeksS.value) == false){
		Poruke.dodajPoruku(2);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(2);
		Poruke.ispisiGreske();		
	}
});

var grupaS = document.getElementById("grupaS");
grupaS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajGrupu(grupaS.value) == false){
		Poruke.dodajPoruku(3);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(3);
		Poruke.ispisiGreske();		
	}
});

var akademskaGodinaS = document.getElementById("akademskaGodinaS");
akademskaGodinaS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajAkGod(akademskaGodinaS.value) == false){
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(4);
		Poruke.ispisiGreske();		
	}
});

var pswS = document.getElementById("pswS");
pswS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajPassword(pswS.value) == false){
		Poruke.dodajPoruku(5);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(5);
		Poruke.ispisiGreske();		
	}
	
});

var pswPotvrdaS = document.getElementById("pswPotvrdaS");
pswPotvrdaS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajPotvrdu(pswS.value, pswPotvrdaS.value) == false){
		Poruke.dodajPoruku(6);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(6);
		Poruke.ispisiGreske();		
	}
});

var bitbucketsshS = document.getElementById("bitbucketsshS");
bitbucketsshS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajBitbucketSSH(bitbucketsshS.value) == false){
		Poruke.dodajPoruku(7);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(7);
		Poruke.ispisiGreske();		
	}
});

var bitbucketurlS = document.getElementById("bitbucketurlS");
bitbucketurlS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajBitbucketURL(bitbucketurlS.value) == false){
		Poruke.dodajPoruku(8);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(8);
		Poruke.ispisiGreske();		
	}
});

var nazivrepozitorijaS = document.getElementById("nazivrepozitorijaS");
var regexN = document.getElementById("regexN");
nazivrepozitorijaS.addEventListener( "focusout", function(){ 
	if(Validacija.validirajNazivRepozitorija(regexN.value, nazivrepozitorijaS.value) == false){
		Poruke.dodajPoruku(9);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(9);
		Poruke.ispisiGreske();		
	}
});

var imePrezimeN = document.getElementById("imePrezimeN");
imePrezimeN.addEventListener( "focusout", function(){ 
	if(Validacija.validirajImeiPrezime(imePrezimeN.value) == false){
		Poruke.dodajPoruku(1);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(1);
		Poruke.ispisiGreske();		
	}
});
var pswN = document.getElementById("pswN");
pswN.addEventListener( "focusout", function(){ 
	if(Validacija.validirajPassword(pswN.value) == false){
		Poruke.dodajPoruku(5);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(5);
		Poruke.ispisiGreske();		
	}
});

var pswPotvrdaN = document.getElementById("pswPotvrdaN");
pswPotvrdaN.addEventListener( "focusout", function(){ 
	if(Validacija.validirajPotvrdu(pswN.value, pswPotvrdaN.value) == false){
		Poruke.dodajPoruku(6);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(6);
		Poruke.ispisiGreske();		
	}
});

var maxGrupaN = document.getElementById("maxGrupaN");
maxGrupaN.addEventListener( "focusout", function(){ 
	if(Validacija.postaviMaxGrupa(maxGrupaN.value) == false){
		Poruke.dodajPoruku(10);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(10);
		Poruke.ispisiGreske();		
	}
});

var semestarN = document.getElementById("semestarN");
semestarN.addEventListener( "focusout", function(){ 
	if(Validacija.postaviTrenSemestar(semestarN.value) == false){
		Poruke.dodajPoruku(11);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(11);
		Poruke.ispisiGreske();		
	}
});

var akademskaGodinaN = document.getElementById("akademskaGodinaN");
akademskaGodinaN.addEventListener( "focusout", function(){ 
	if(Validacija.validirajAkGod(akademskaGodinaN.value) == false){
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
	}
	else{
		Poruke.ocistiGresku(4);
		Poruke.ispisiGreske();		
	}
});