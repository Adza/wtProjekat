function zamjeniGore(element){
			var red = element.parentNode.parentNode;
			var prethodni = red.previousSibling;
			if(prethodni != null && prethodni.nodeType == 3)
				prethodni = prethodni.previousSibling;
			var tabela = red.parentNode;
			console.log(prethodni);
			if(prethodni != null  && prethodni.id != 'prvi'){
				tabela.insertBefore(red,prethodni);
			}
			console.log(tabela);
		}
function zamjeniDole(element){
			var red = element.parentNode.parentNode;
			var prethodni = red.nextSibling;
			if(prethodni != null && prethodni.nodeType == 3)
				prethodni = prethodni.nextSibling;
			var tabela = red.parentNode;
			console.log(prethodni);
			if(prethodni != null  && prethodni.id != 'prvi'){
				tabela.insertBefore(prethodni,red);
			}
			console.log(tabela);
		}
	