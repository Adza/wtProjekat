var Poruke=(function(){
	var idDivaPoruka;
	var mogucePoruke=["Email koji ste napisali nije validan fakultetski email", "Ime i prezime nije validno" ,
	"Indeks kojeg ste napisali nije validan",
	"Nastavna grupa koju ste napisali nije validna", "Akademska godina nije validna", "Password nije validan", "Uneseni passwordi nisu jednaki",
	"Bitbucket SSH nije validan", "Bitbucket URL nije validan", "Naziv repozitorija nije validan", "Broj grupa nije validan", "Trenutni semestar nije validan. Unesite 0 za zimski ili 1 za ljetni semestar" ];
	
	var porukeZaIspis=[];

	var ispisiGreske = function(){
		var greske = document.getElementById(idDivaPoruka);
		greske.innerHTML = "";
		for(var i = 0; i < porukeZaIspis.length; i++){
				greske.innerHTML += porukeZaIspis[i] + "<br>";
			}
	}
	var postaviIdDiva = function(idDiva){
		idDivaPoruka = idDiva;
	}
	var dodajPoruku = function(indexPoruke){
		var bool = false;
		for(var i = 0; i < porukeZaIspis.length; i++){
			if(porukeZaIspis[i] == mogucePoruke[indexPoruke])
				bool = true;
		}
		if(bool == false)
			porukeZaIspis.push(mogucePoruke[indexPoruke]);
	}
	var ocistiGresku = function(indexPoruke){
		for(i=0; i<porukeZaIspis.length; i++)
		{
			if(porukeZaIspis[i] == mogucePoruke[indexPoruke])
				porukeZaIspis.splice(i,1);
		}
	}
	

	return{
		ispisiGreske: ispisiGreske,
		postaviIdDiva: postaviIdDiva,
		dodajPoruku: dodajPoruku,
		ocistiGresku: ocistiGresku
	}
}());
Poruke.postaviIdDiva("greske");