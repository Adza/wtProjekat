var BitbucketApi = (function(){
       var dohvatiAccessToken=function(key, secret, fnCallback){
        if(key==null || secret==null ) {
          fnCallback( -1, { message: "Key ili secret nisu pravilno proslijeđeni!" } )
          return;
        }
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() { //Anonimna funkcija
            if (ajax.readyState == 4 && ajax.status == 200)
                fnCallback(null, JSON.parse(ajax.responseText).access_token);
            else if (ajax.readyState == 4)
                fnCallback(ajax.status, null);
        }
        ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
        ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ":" + secret));
        ajax.send("grant_type="+encodeURIComponent("client_credentials"));
      }
    var dohvatiRepozitorije= function(token, godina, naziv, branch, fnCallback){
        let repozitoriji = [];
        let elementiBrisanje = [];
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function(){
           if (ajax.readyState == 4 && ajax.status == 200)
               {
                   var values = JSON.parse(ajax.responseText).values;
                   values = values.filter( function( value ){
                     let d = new Date(value.created_on);
                     return d.getFullYear() == godina || d.getFullYear() == (parseInt(godina) + 1) ;
                   } ) //repozitoriji koji su kreirani godine koja je prosljeđena kao parametar ili naredne godine
                  for(let i = 0; i<values.length; i++){
                    repozitoriji.push(values[i].links.clone[1].href); //ssh repozitoriji da se dobiju, sta api vraca http://arjanvandergaag.nl/blog/wrestling-json-with-jq.html
                    elementiBrisanje.push(null);
                  }
                  for(let i = 0; i<values.length; i++) //prilikom poziva dohvatiBranc prosljedimo href
                    BitbucketApi.dohvatiBranch( token, values[i].links.branches.href, branch, function( err, data ){
                      filtriraj( i, data, fnCallback, repozitoriji, elementiBrisanje ) //da izvrsi filtriranje
                    } )
               }
           else if (ajax.readyState == 4)
               fnCallback(ajax.status, null)
        }
        ajax.open("GET", "https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150&q=name" + encodeURIComponent('~"') + naziv + encodeURIComponent('"'));
        ajax.setRequestHeader("Authorization", 'Bearer ' + token);
        ajax.send();
    }
    var dohvatiBranch= function(token, url, naziv, fnCallback){
            let ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
              if (ajax.readyState == 4 && ajax.status == 200){ //naziv je ime brancha kojeg trebamo dohvatiti
                let values = JSON.parse(ajax.responseText).values;
                values = values.filter( function(x){ 
                  return x.name.indexOf(naziv) > -1  //vraca true ili false, indexof vraca poziciju prvog pojavljivanja odr stringa i vraca -1 ako ne postoji
                } );
                var postoji;
                if(values.length>0) //drugi parametar data zavisno dal branch postoji, provjeravamo da li niz ima barem jedan element
                    postoji=true;
                else
                    postoji=false;

                fnCallback(null, postoji); 
              }
              else if( ajax.readyState == 4 )
                fnCallback( ajax.status,"Greska" );
            }
            ajax.open("GET", url); //slanje preko URL koji je prosljedjen kao parametar
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
          }
          function filtriraj( ind, brisanje, fnCallback, repozitorij, elementiBrisanje ){
            if(!elementiBrisanje[ind])
              repozitorij[ind] = null;
            elementiBrisanje[ind] = brisanje;      
            if(elementiBrisanje.indexOf(null) > -1 ) return;
            repozitorij = repozitorij.filter( function( x ){
              return x != null
            } );
        
            fnCallback(null, repozitorij)
        }
    return {
    dohvatiAccessToken: dohvatiAccessToken,
    dohvatiRepozitorije:dohvatiRepozitorije,
    dohvatiBranch: dohvatiBranch
    }
    })();


        