var KreirajFajl=(function(){
    var kreirajKomentar=function(spirala, index, sadrzaj, fnCallback)
    {        
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
        var regStringSaBarJednimZnakom =/^[A-Za-z]+$/g;
        function testJSON(text){
            try{
                JSON.parse(text);
                if(typeof text.sifra_studenta != "undefined" && typeof text.tekst != "undefined" && typeof text.sadrzaj != "undefined")
                    return false;
                return true;
            }
            catch (error){
                return false;
            }
        }
            if (ajax.readyState == 4 && ajax.status == 200){
                    var jsonRez = JSON.parse(ajax.responseText);
                    fnCallback(null,ajax.responseText); //funkcija sa parametrima error i data
                }
                else if (ajax.readyState == 4) // ako se desila greska
                    fnCallback(ajax.statusText,ajax.responseText);
                else if(!regStringSaBarJednimZnakom.test (spirala) || !regStringSaBarJednimZnakom.test(index) || testJSON(sadrzaj) ) 
                {
                    fnCallback(-1,{ message: "Neispravni parametri" });
                }
            }
            const params = {
                spirala:spirala,
                index: index,
                sadrzaj:sadrzaj
            }
    
            ajax.open("POST","http://localhost:3000/komentar",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(params));         

       
    }
    var kreirajListu=function(godina, nizRepozitorija, fnCallback)
    {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
        var regStringSaBarJednimZnakom =/^[A-Za-z]+$/g;
            if (ajax.readyState == 4 && ajax.status == 200){
                var jsonRez = JSON.parse(ajax.responseText);
                fnCallback(null,ajax.responseText); //funkcija sa parametrima error i data
            }
            else if (ajax.readyState == 4) // ako se desila greska
                fnCallback(ajax.statusText,ajax.responseText);
            else if(!regStringSaBarJednimZnakom.test (godina) || nizRepozitorija.lenghth<1)
            {
                fnCallback(-1,{ message: "Neispravni parametri" });
            }
            }
            const params = {
                godina:godina,
                nizRepozitorija:nizRepozitorija
            }
    
            ajax.open("POST","http://localhost:3000/lista",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(params));
    }
    var kreirajIzvjestaj=function(spirala,index, fnCallback)
    {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
        var regStringSaBarJednimZnakom =/^[A-Za-z]+$/g;
            if (ajax.readyState == 4 && ajax.status == 200){
                var jsonRez = JSON.parse(ajax.responseText);
                fnCallback(null,ajax.responseText); //funkcija sa parametrima error i data
            }
            else if (ajax.readyState == 4) // ako se desila greska
                fnCallback(ajax.statusText,ajax.responseText);
            else if(!regStringSaBarJednimZnakom.test (index))
            {
                fnCallback(-1,{ message: "Neispravni parametri" });
            }
            }
            const params = {
                spirala:spirala,
                index:index
            }
    
            ajax.open("POST","http://localhost:3000/izvjestaj",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(params));
    }
    var kreirajBodove=function(spirala,index, fnCallback)
    {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
        var regStringSaBarJednimZnakom =/^[A-Za-z]+$/g;
            if (ajax.readyState == 4 && ajax.status == 200){
                var jsonRez = JSON.parse(ajax.responseText);
                fnCallback(null,ajax.responseText); //funkcija sa parametrima error i data
            }
            else if (ajax.readyState == 4) // ako se desila greska
                fnCallback(ajax.statusText,ajax.responseText);
            else if(!regStringSaBarJednimZnakom.test (index))
            {
                fnCallback(-1,{ message: "Neispravni parametri" });
            }
            }
            const params = {
                spirala:spirala,
                index:index
            }
    
            ajax.open("POST","http://localhost:3000/bodovi",true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(params));
    }
    
    return {
    kreirajKomentar: kreirajKomentar,
    kreirajListu:kreirajListu,
    kreirajIzvjestaj:kreirajIzvjestaj,
    kreirajBodove:kreirajBodove
    }
    })();