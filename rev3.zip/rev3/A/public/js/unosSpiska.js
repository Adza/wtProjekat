var fs = require('fs');
var ValidacijaSpiska=(function(){
   
    var validirajSpisak=function(email) 
    {
        document.getElementById("greska").innerHTML = "";
        var podaciPoRedovima=document.getElementsByName("spisak").innerHTML.split("\n");
        var podaciPoKolononama = [];
        for(i=0; i<podaciPoRedovima.length; i++){
            podaciPoKolononama.push(podaciPoRedovima.split(","));
            var provjera=Array.from(new Set(podaciPoKolononama[i])); //ova funkcija brise sve elemente koji se ponavljaju ostavljajuci unique elemente
            if(provjera.length!=podaciPoKolononama[i]) //ukoliko je bilo duplih elemenata validacija ne prolazi
                return false;
        }
        return true;
        
    }
    return{
        validirajSpisak: validirajSpisak
    }
}());

var spisak = document.getElementById("spisak");
spisak.addEventListener( "focusout", function(){ 
	if(ValidacijaSpiska.validirajSpisak(spisak.value) == false){
		document.getElementById("greska").innerHTML = "U jednom redu index se smije nalaziti samo jednom!";
	}
	else{
        document.getElementById("greska").innerHTML=="";
        var redovi=document.getElementsByName("spisak").value.split("\n");
        var odgovor = redovi.map(function(ulaz){ //vraca niz objekata
            var polja = ulaz.split(',');
            return {
              student: polja[0],
              A: polja[1],
              B: polja[2],
              C: polja[3],
              D: polja[3],
              E: polja[3]
            };
          });
          JSONobjekat=JSON.stringify(odgovor);	
          document.getElementById("greska").innerHTML=="Datoteka je kreirana";
          var spirala="spisakS";
          var x=document.getElementById("greska").value; //ime dokumenta mora biti spisakSX
          spirala+=x;
          if(document.getElementById("greska").innerHTML==1)
            fs.writeFile(spirala+".json", JSONobjekat);
	}
});