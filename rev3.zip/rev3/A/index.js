var express = require('express');
var fs = require('fs');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});


app.use(express.static(path.join(__dirname, '/public')));

app.get('/',function(req,res){
  res.sendFile(__dirname + '/views/index.html');
});

app.get('/login',function(req,res){
  res.sendFile(__dirname + '/views/login.html');
});

app.get('/statistika',function(req,res){
  res.sendFile(__dirname + '/views/statistika.html');
});

app.get('/unoskomentara',function(req,res){
  res.sendFile(__dirname + '/views/unoskomentara.html');

});

app.post('/komentar',function(req,res){
  var javaobj = req.body;
  var brojSpirale=javaobj.spirala;
  var brojIndexa=javaobj.index;
  var jsonPodaci="markS"+brojSpirale+brojIndexa+".json";
  var json = JSON.stringify(javaobj);
  function testJSON(text){
    try{
        //JSON.parse(text);
        if(typeof text.spirala == "undefined" || typeof text.index == "undefined" || typeof text.sadrzaj == "undefined")
            return false;
        return true;
    }
    catch (error){
        return false;
    }
}

// fs.readFile(jsonPodaci, 'utf8', function readFileCallback(err, data){
//   if (err){
//       console.log(err);
//   } else {
    if(testJSON(javaobj)){
        fs.appendFile(jsonPodaci, json, 'utf8', function (err) {
            if(err)
                consol.log(err);
        });
        res.json({ "message": "Uspješno kreirana datoteka!" , data:json });
    }
    else
    {
        res.json({"message":"Podaci nisu u traženom formatu!" ,data:null});
    }
//}});

});



app.post('/lista',function(req,res){
  
  //{‘godina’:’2017’,’nizRepozitorija’:[‘link repozitorija 1’,’link repozitorija 2’,...]}
  //spisakXXXX.txt
    var javaobj = req.body;
    //var javaobj=JSON.parse(tijelo);
    var brojGodine=javaobj.godina;
    var imeDatoteke="spisak"+brojGodine+".txt";
    var upisUDatoteku = JSON.stringify(javaobj.nizRepozitorija);
    function testJSON(text){
        try{
              //JSON.parse(text);
              if(typeof text.godina == "undefined" || typeof text.nizRepozitorija == "undefined")
                  return false;
              return true;
          }
          catch (error){
              return false;
          }
    }
  
  
  // fs.readFile(jsonPodaci, 'utf8', function readFileCallback(err, data){
  //   if (err){
  //       console.log(err);
  //   } else {
        if(testJSON(javaobj)){
            fs.writeFile(imeDatoteke, upisUDatoteku, 'utf8', function (err) {
                if(err)
                    console.log(err);
            });
            
            res.json({ "message": "message”:”Lista uspješno kreirana" , data:100 });
        }
        else
        {
            res.json({"message":"Podaci nisu u traženom formatu!" ,data:null});
        }
  // }});
  
  });




  app.post('/izvjestaj',function(req,res){
    
    //{‘spirala’:’1’,‘index’:’12345’}
    //izvjestajSNXXXX.txt
      var javaobj= req.body;
      var brojSpirale=javaobj.spirala;
      var brojIndexa=javaobj.index;
      var jsonPodaci="izvjestajS"+brojSpirale+brojIndexa+".txt";
      var json = JSON.stringify(javaobj);
      function testJSON(text) {
          try {
              //JSON.parse(text);
              if (typeof text.spirala == "undefined" || typeof text.index == "undefined" || typeof text.sadrzaj == "undefined" || text.index.length === 0)
                  return false;
              return true;
          }
          catch (error) {
              return false;
          }
      }
      if(testJSON(javaobj)){
          fs.writeFile(jsonPodaci, json, 'utf8', function (err) {
              if(err)
                  console.log(err);
          });

          res.json({ "message": "message”:”Lista uspješno kreirana" , data:100 });
      }
      else
      {
          res.json({"message":"Podaci nisu u traženom formatu!" ,data:null});
      }
    });
  
    app.post('/bodovi',function(req,res){
      
      //{‘spirala’:’1’,‘index’:’12345’}, odgovor se dobija kao {‘poruka’:’Student 12345 je ostvario u prosjeku 2 mjesto’}
      //markSXNNNNN.json s

        var javaobj= req.body;
        var brojSpirale=javaobj.spirala;
        var brojIndexa=javaobj.index;
        var jsonPodaci="markS"+brojSpirale+brojIndexa+".json";
        var json = JSON.stringify(javaobj);
        function testJSON(text) {
            try {
                //JSON.parse(text);
                if (typeof text.spirala == "undefined" || typeof text.index == "undefined" || typeof text.sadrzaj == "undefined" || text.index.length === 0)
                    return false;
                return true;
            }
            catch (error) {
                return false;
            }
        }
        if(testJSON(javaobj)){
            fs.writeFile(jsonPodaci, json, 'utf8', function (err) {
                if(err)
                    console.log(err);
            });

            res.json({ "message": "message”:”Lista uspješno kreirana" , data:100 });
        }
        else
        {
            res.json({"message":"Podaci nisu u traženom formatu!" ,data:null});
        }
      
      });
    









app.listen(3000);