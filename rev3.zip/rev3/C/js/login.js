function provjeriStudentFormu(what, where) {
    form = document.getElementById("student_form");
    Poruke.postaviIdDiva(where);

    Validacija.postaviTrenSemestar(form.currsem);

    if ( !Validacija.validirajImeiPrezime(form.name.value) ) {
		if ( what === 'name' ) {
            Poruke.dodajPoruku(Poruke.ERROR_IME_PREZIME);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_IME_PREZIME);
    }


    if ( !Validacija.validirajAkGod(form.ay.value, false) ) {
        if ( what === 'ay' ) {
            Poruke.dodajPoruku(Poruke.ERROR_AKADEMSKA);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_AKADEMSKA);
    }

    if ( !Validacija.validirajPassword(form.pw.value) ) {
        if ( what === 'pw' ) {
            Poruke.dodajPoruku(Poruke.ERROR_NESIGURAN_PASSWORD);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_NESIGURAN_PASSWORD);
    }

    if ( !Validacija.validirajPotvrdu(form.pw.value, form.pw2.value) ) {
        if ( what === 'pw2' ) {
            Poruke.dodajPoruku(Poruke.ERROR_POTVRDA_PASSWORD);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_POTVRDA_PASSWORD);
    }

    if ( !Validacija.validirajBitbucketSSH(form.bbssh.value) ) {
        if ( what === 'bbssh' ) {
            Poruke.dodajPoruku(Poruke.ERROR_BB_SSH);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_BB_SSH);
    }

    if ( !Validacija.validirajBitbucketURL(form.bburl.value) ) {
        if ( what === 'bburl' ) {
            Poruke.dodajPoruku(Poruke.ERROR_BB_URL);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_BB_URL);
    }

    if ( !Validacija.validirajNazivRepozitorija(null, form.reponame.value) ) {
        if ( what === 'reponame' ) {
            Poruke.dodajPoruku(Poruke.ERROR_REPO_NAME);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_REPO_NAME);
    }

    if ( !Validacija.validirajGrupu(form.group.value) ) {
        if ( what === 'group' ) {
            Poruke.dodajPoruku(Poruke.ERROR_NASTAVNA_GRUPA);
        }
    } else {
        Poruke.ocistiGresku(Poruke.ERROR_NASTAVNA_GRUPA);
    }

    if ( !Validacija.validirajIndex(form.index.value) ) {
        if ( what === 'index' ) {
            Poruke.dodajPoruku(Poruke.ERROR_INDEX);
        }
    } else {
        Poruke.ocistiGresku(Poruke.ERROR_INDEX);
    }

    Poruke.ispisiGreske();
}

function provjeriNastavnikFormu(what, where) {
    form = document.getElementById("nastavnik_form");

    Poruke.postaviIdDiva(where);

    Validacija.postaviMaxGrupa(form.maxgroups);
    Validacija.postaviTrenSemestar(form.currsem);

    if ( !Validacija.validirajImeiPrezime(form.name.value) ) {
        if ( what === 'name' ) {
            Poruke.dodajPoruku(Poruke.ERROR_IME_PREZIME);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_IME_PREZIME);
    }
    if ( !Validacija.validirajFakultetski(form.email.value) ) {
        if ( what === 'email' ) {
            Poruke.dodajPoruku(Poruke.ERROR_EMAIL);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_EMAIL);
    }
    if ( !Validacija.validirajAkGod(form.curray.value, true) ) {
        if ( what === 'curray' ) {
            Poruke.dodajPoruku(Poruke.ERROR_AKADEMSKA);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_AKADEMSKA);
    }
    if ( !Validacija.validirajPassword(form.password.value) ) {
        if ( what === 'password' ) {
            Poruke.dodajPoruku(Poruke.ERROR_NESIGURAN_PASSWORD);
        }
	} else {
        Poruke.ocistiGresku(Poruke.ERROR_NESIGURAN_PASSWORD);
    }
    if ( !Validacija.validirajPotvrdu(form.password, form.passwordconfirm.value) ) {
        if ( what === 'passwordconfirm' ) {
            Poruke.dodajPoruku(Poruke.ERROR_POTVRDA_PASSWORD);
        }
    } else {
        Poruke.ocistiGresku(Poruke.ERROR_POTVRDA_PASSWORD);
    }

    Poruke.ispisiGreske();
}

function ocistiFormu(formId) {
    for ( var i = 0; i < 10; ++ i ) {
        Poruke.ocistiGresku(i);
    }


    document.getElementById(formId).reset();
}