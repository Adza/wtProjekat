var KreirajFajl=(function(){
    return {
        kreirajKomentar: function(spirala, index, sadrzaj, fnCallback){
            var sadrzajValidan = true;
            if ( sadrzaj.constructor !== Array ) {
                // nije niz
                sadrzajValidan = false;
            } else {
                sadrzaj.forEach(function (value) {
                    //provjeri da li svaki element niza ima trazene atribute

                    if ( value.sifra_studenta === undefined ||
                         value.tekst === undefined ||
                         value.ocjena === undefined ) {
                        sadrzajValidan = false;
                    }
                });
            }

            if ( sadrzajValidan === false || typeof(spirala) !== 'string' || typeof(index) !== 'string'
                || spirala.length === 0 || index.length === 0 ) {

                fnCallback(-1, "Neispravni parametri");
                return;
            }


            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                }
                else if (ajax.readyState == 4) {
                    fnCallback(ajax.status, ajax.responseText);
                }
            };
            ajax.open("POST","http://localhost:3000/komentar", true);

            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(
                {
                    spirala: spirala,
                    index: index,
                    sadrzaj: sadrzaj
                }
            ));
        },
        kreirajListu: function(godina, nizRepozitorija, fnCallback){
            var valid = true;

            if ( typeof(godina) !== 'string' || godina.length === 0 ) {
                valid = false;
            }

            if ( nizRepozitorija.constructor !== Array ) {
                valid = false;
            } else if ( nizRepozitorija.length === 0 ) {
                valid = false;
            }

            if ( valid === false ) {
                fnCallback(-1, "Neispravni parametri");
                return;
            }

            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                }
                else if (ajax.readyState == 4) {
                    fnCallback(ajax.status, ajax.responseText);
                }
            };

            ajax.open("POST","http://localhost:3000/lista", true);

            ajax.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

            ajax.send(JSON.stringify(
                {
                    godina: godina,
                    nizRepozitorija: nizRepozitorija
                }
            ));
        },
        kreirajIzvjestaj: function(spirala,index, fnCallback){
            if ( typeof(index) !== 'string' || index.length === 0 ) {
                fnCallback(-1, "Neispravni parametri");
                return;
            }

            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                }
                else if (ajax.readyState == 4) {
                    fnCallback(ajax.status, ajax.responseText);
                }
            };
            ajax.open("POST","http://localhost:3000/izvjestaj", true);

            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(
                {
                    spirala: spirala,
                    index: index
                }
            ));
        },
        kreirajBodove: function(spirala,index, fnCallback){
            if ( typeof(index) !== 'string' || index.length === 0 ) {
                fnCallback(-1, "Neispravni parametri");
                return;
            }

            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function() {
                if (ajax.readyState == 4 && ajax.status == 200){
                    fnCallback(null, ajax.responseText);
                }
                else if (ajax.readyState == 4) {
                    fnCallback(ajax.status, ajax.responseText);
                }
            };
            ajax.open("POST","http://localhost:3000/bodovi", true);

            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.send(JSON.stringify(
                {
                    spirala: spirala,
                    index: index
                }
            ));
        }
    }
})();
