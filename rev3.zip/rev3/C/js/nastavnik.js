function generisiIzvjestaj() {
    var index = document.getElementById("index").value;
    var spirala = document.getElementById("spirala").value;

    KreirajFajl.kreirajIzvjestaj(spirala, index, function(error, data) {
        while ( data.indexOf("\n") !== -1 ) {
            data = data.replace("\n", "</br>");
        }

        var obj = JSON.parse(data);
        if ( obj.message === "OK" ) {
            // generisanje uspjesno, downloaduj fajl
            var js = "window.open('http://localhost:3000/downloadIzvjestaj?file=" + obj.data + "', '_blank');";

            document.getElementById("output").innerHTML =
                "<button class='button' onclick=\"" + js + "\">Downloaduj izvjestaj</button>";

        } else {
            document.getElementById("output").innerHTML = message;
        }
    });
}

function generisiBodove() {
    var index = document.getElementById("index").value;
    var spirala = document.getElementById("spirala").value;

    KreirajFajl.kreirajBodove(spirala, index, function (error, data) {
        document.getElementById("output").innerHTML = JSON.parse(data).poruka;
    });
}