function moveRow(id, deltaPos) {
    var rowParent = document.getElementById('row_parent');

    var rows = rowParent.children;
    for ( var i = 0; i < rows.length; ++ i ) {
        var row = rows[i];
        if ( row.id !== id ) {
            continue;
        }
        var targetIndex = i + deltaPos;
        if ( targetIndex >= rows.length || targetIndex < 0 ) {
            continue;
        }

        var refrow = rows[targetIndex];

        var clonedElement1 = row.cloneNode(true);
        var clonedElement2 = refrow.cloneNode(true);

        rowParent.replaceChild(clonedElement1, refrow);
        rowParent.replaceChild(clonedElement2, row);

        clonedElement1.setAttribute('id', row.id);
        clonedElement2.setAttribute('id', refrow.id);

        break;
    }
}

function makeRow(id, sifra) {
    var template = '<tr id="__ID__">\n' +
        '                <td>\n' +
        '                    <div class="vertical">\n' +
        '                        <i class="fa fa-thumbs-o-up" onclick="moveRow(\'__ID__\', -1)"></i>\n' +
        '                        <i class="fa fa-thumbs-o-down"  onclick="moveRow(\'__ID__\', 1)"></i>\n' +
        '                    </div>\n' +
        '                </td>\n' +
        '                <td id="__ID___sifra" class="horizontal-center">___sifra___</td>\n' +
        '                <td class="horizontal-center"><a href="#">Link</a></td>\n' +
        '                <td><textarea id="__ID___komentar"></textarea></td>\n' +
        '            </tr>';


    while ( template.indexOf("__ID__") !== -1 ) {
        template = template.replace("__ID__", id);
    }

    template = template.replace("___sifra___", sifra);

    return template;
}

function makeReviewTable(tableBodyId) {
    var body = document.getElementById(tableBodyId);

    var html = "";
    var sifre = [ "A", "B", "C", "D", "E" ];

    for ( var i = 0; i < sifre.length; ++ i ) {
        html += makeRow("red_" + i, sifre[i]);
    }

    body.innerHTML = html;
}


function submitReview(tableBodyId) {
    var body = document.getElementById(tableBodyId);

    var index = document.getElementById("curr_index").value;
    var spirala = document.getElementById("curr_spirala").value;

    var arr = [];

    for ( var i = 0; i < body.children.length; ++ i ) {
        var id = body.children[i].id;

        var sifra = document.getElementById(id + "_sifra").innerText;
        var komentar = document.getElementById(id + "_komentar").value;

        arr.push(
            {
                sifra_studenta: sifra,
                ocjena: i,
                tekst: komentar
            }
        );
    }

    KreirajFajl.kreirajKomentar(spirala, index, arr, function(err, data) {
        document.getElementById("output").innerHTML = JSON.parse(data).message;
    });
}