var Validacija=(function(){
    var maxGrupa=7;
    var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar

return{
    validirajFakultetski: function(email) {
        var a = email.indexOf("@etf.unsa.ba");
        if ( a < 0 ) return false;
        return email.substring(a) === "@etf.unsa.ba";
    },

    validirajIndex: function(index) {
        var str = index + "";
        return str.length === 5 && str[0] === '1';
    },

    validirajGrupu : function(grupa) {
        return grupa > 0 && grupa < maxGrupa;
    },

    validirajAkGod: function(ay, moraBitiTrenutna) {
        var expr = /(20..)\/(20..)/;

        if ( ay.length !== 9 ) return false;
        if ( !expr.test(ay) ) return false;

        var matches = ay.match(expr);
        var trenutna;

        var a = parseInt(matches[1]);
        var b = parseInt(matches[2]);
        if ( b - a !== 1 ) return false; // mora vrijediti a + 1 = b

        if ( trenutniSemestar === 0 ) {
            //zimski
            trenutna = a;
        } else {
            //ljetni
            trenutna = b;
        }


        return !moraBitiTrenutna || trenutna === (new Date()).getFullYear();
    },

    validirajPassword: function(pw) {
        if ( pw.length < 7 || pw.length > 20 ) return false;

        return /.*[0-9]+.*/.test(pw) && /.*[A-Z]+.*/.test(pw) && /.*[a-z]+.*/.test(pw);
    },

    validirajPotvrdu: function(a, b) {
        return a === b;
    },
    validirajBitbucketURL: function(url) {
        return /https:\/\/(.*)@bitbucket.org\/\1(2)\/(.*).git/.test(url);
    },
    validirajBitbucketSSH: function(str) {
        return /git@bitbucket.org:(.*)\/(.*).git/.test(str);
    },
    validirajNazivRepozitorija: function(expr, str) {
        if ( expr === null ) {
            return /wt[pP]rojekat1[0-9]{4}/.test(str)
        } else {
            return expr.test(str);
        }
    },
    validirajImeiPrezime: function(str) {
        var bhSlova = "šđžčć";
        bhSlova += bhSlova.toUpperCase();

        str = str.trim();
        if ( str.length === 0 ) {
            return false;
        }

        if ( str[0] === '-' || str[0] === '\'' ) {
            return false;
        }

        var words = str.split(" ");
        for ( var i = 0; i < words.length; ++ i ) {
            words[i] = words[i].trim();
            if ( words[i].length === 0 ) {
                continue;
            }

            if ( words[i][0] !== words[i][0].toUpperCase() ) {
                return false;
            }

            words[i] = words[i].replace("-", "");
            words[i] = words[i].replace("'", "");

            for ( var c = 0; c < bhSlova.length; ++ c ) {
                words[i] = words[i].replace(bhSlova[c], '');
            }

            words[i] = words[i].replace(/[A-z]*/, "");

            if ( words[i].length !== 0 ) return false;
        }

        return true;
    },
    postaviMaxGrupa: function(mg) {
        maxGrupa = mg;
    },
    postaviTrenSemestar: function(sem) {
        trenutniSemestar = sem;
    }


}
}());
