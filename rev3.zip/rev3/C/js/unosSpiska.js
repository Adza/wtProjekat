function submitSpisak() {
    var spirala = document.getElementById('inputSpirala').value;
    var csv = document.getElementById('spisakCsv').value;

    var lines = csv.split('\n');

    var valid = true;

    var res = [];

    var message = "";

    var k = 0;
    lines.forEach(function (line) {
        ++k;
        if (!valid) return;

        line = line.trim();
        if ( line.length === 0 ) {
            return;
        }


        var columns = line.split(",");

        if ( columns.length !== 6 ) {
            //svaki red mora imati 6 kolona
            message = "Svaki red mora imati tacno 6 kolona! red " + k;
            valid = false;
        }

        // u jednom redu se ne smije pojaviti 2 puta isti indeks
        for ( var i = 0; i < columns.length; ++ i ) {
            if ( columns[i].trim().length === 0 ) {
                message = "Svaki indeks mora imati barem 1 karakter! red " + k;
                valid = false; // svaki indeks mora imati barem 1 karakter
            }

            for ( var j = i + 1; j < columns.length; ++ j ) {
                if ( columns[i] === columns[j] ) {
                    message = "U jednom redu se ne smije pojaviti 2 puta isti indeks! red " + k;
                    valid = false;
                    break;
                }
            }
        }

        res.push(columns);
    });

    if ( !valid ) {
        document.getElementById("output").innerHTML = "Neispravan CSV! " + message;
        return;
    }


    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById("output").innerHTML = JSON.parse(ajax.responseText).message;
        }
        else if (ajax.readyState == 4) {
            document.getElementById("output").innerHTML = ajax.responseText;
        }
    };
    ajax.open("POST","http://localhost:3000/spisak", true);

    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(
        {
            spirala: spirala,
            spisak: res
        }
    ));
}