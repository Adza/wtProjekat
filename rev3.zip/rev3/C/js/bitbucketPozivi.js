function generisiListu() {
    BitbucketApi.dohvatiAccessToken(
        document.getElementById('key').value,
        document.getElementById('secret').value,
        function(error, data) {
            if ( error ) {
                document.getElementById('output').innerHTML = "Greska pri dohvatanju access tokena!";
            } else {
                var godina = document.getElementById("year").value;
                var naziv = document.getElementById('repo').value;
                var branch = document.getElementById('branch').value;

                BitbucketApi.dohvatiRepozitorije(data, godina, naziv, branch, function(err, data) {
                    if ( error ) {
                        document.getElementById('output').innerHTML = data;
                    } else {
                        KreirajFajl.kreirajListu(godina, data, function(err, data) {
                            if ( err ) {
                                document.getElementById('output').innerHTML = data;
                                return;
                            }

                            var obj = JSON.parse(data);

                            if ( obj.data !== null ) {
                                document.getElementById('output').innerHTML =
                                    "Lista uspješno kreirana sa " + obj.data + " studenata.";
                            } else {
                                //greska
                                document.getElementById('output').innerHTML = obj.message;
                            }
                        });
                    }
                });
            }
        }
    );

}