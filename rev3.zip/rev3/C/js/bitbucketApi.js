var BitbucketApi = (function() {
    return {
        dohvatiAccessToken: function(key, secret, fnCallback){
            var ajax = new XMLHttpRequest();

            if ( key === null || secret === null ) {
                fnCallback(-1, "Key ili secret nisu pravilno proslijeđeni!");
                return;
            }

            ajax.onreadystatechange = function() {// Anonimna funkcija
                if (ajax.readyState == 4 && ajax.status == 200) {
                    fnCallback(null, JSON.parse(ajax.responseText).access_token);
                }
                else if (ajax.readyState == 4) {
                    fnCallback(ajax.status, null);
                }
            };
            ajax.open("POST", "https://bitbucket.org/site/oauth2/access_token", true);
            ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            ajax.setRequestHeader("Authorization", 'Basic ' + btoa(key + ':' + secret));
            ajax.send("grant_type="+encodeURIComponent("client_credentials"));
        },
        dohvatiBranch: function(token, url, naziv, fnCallback) {
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if ( ajax.readyState === 4 && ajax.status !== 200 ) {
                    fnCallback(ajax.status, false);
                } else if ( ajax.readyState === 4 ) {
                    var obj = JSON.parse(ajax.responseText);

                    var exists = false;
                    obj.values.forEach(function (value) {
                        if ( value.name === naziv ) {
                            exists = true;
                        }
                    });
                    fnCallback(null, exists);
                }
            };
            ajax.open("GET", url);
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        },
        dohvatiRepozitorije: function(token, godina, naziv, branch, fnCallback) {
            if ( typeof(godina) === 'string' ) {
                godina = parseInt(godina);
            }

            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function(){
                if (ajax.readyState == 4 && ajax.status == 200)
                {
                    var obj = JSON.parse(ajax.responseText);

                    //posto se dohvatiBranch izvrsava asinhrono, pamtim broj koliko ce
                    //se puta pozvati i dekrementiram pri svakom pozivu.
                    //Pa kada broj padne na 0, pozivam callback.
                    var queue = obj.values.length;
                    var res = [];

                    obj.values.forEach(function (value) {
                        value.created_on = new Date(value.created_on);

                        if (value.created_on.getFullYear() !== godina &&
                            value.created_on.getFullYear() !== godina + 1 ) {
                            queue--;

                            if ( queue === 0 ) {
                                fnCallback(null, res);
                            }
                            return;
                        }

                        if ( value.name.indexOf(naziv) === -1 ) {
                            queue--;

                            if ( queue === 0 ) {
                                fnCallback(null, res);
                            }
                            return;
                        }

                        BitbucketApi.dohvatiBranch(token, value.links.branches.href, branch, function (error, data) {
                            queue--;


                            if (data && value.links.clone !== undefined) {
                                var ssh = null;
                                value.links.clone.forEach(function (v2) {
                                    if (v2.name === "ssh") {
                                        ssh = v2.href;
                                    }
                                });
                                res.push(ssh);
                            }

                            if (queue === 0) {
                                //dohvatili smo sve brancheve
                                fnCallback(null, res);
                            }
                        });
                    });

                }
                else if (ajax.readyState === 4) {
                    fnCallback(ajax.status, [])
                }
            };
            ajax.open("GET","https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150");
            ajax.setRequestHeader("Authorization", 'Bearer ' + token);
            ajax.send();
        }
    }
})();
