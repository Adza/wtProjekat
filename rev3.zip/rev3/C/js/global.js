

function showPanel(panelParentId, targetId) {
    var parent = document.getElementById(panelParentId);
    var target = document.getElementById(targetId)
    var panels = parent.getElementsByClassName("panel");

    for ( var i = 0; i < panels.length; ++ i ) {
        if ( panels[i].parentNode !== target.parentNode ) continue;
        if ( panels[i].classList.contains("hidden") ) continue;
        panels[i].classList.add("hidden");
    }

    target.classList.remove("hidden");

    Poruke.ispisiGreske();
}


function load(modName, oncomplete) {
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {// Anonimna funkcija
        if (ajax.readyState == 4 && ajax.status == 200){
            document.getElementById('page-content').innerHTML = ajax.responseText;

            if ( oncomplete !== undefined ) {
                oncomplete();
            }
        }
        else if (ajax.readyState == 4)
            console.log(ajax.statusText);
    };
    ajax.open("GET","http://localhost:3000/" + modName, true);

    //ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(); //JSON.stringify({pokusaj:pokusaj})
}