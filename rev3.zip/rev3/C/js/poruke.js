var Poruke= (function() {
    var idDivaPoruka;
    var mogucePoruke=
        [
            "Uneseno ime ili prezime nije validno",
            "Akademska godina nije validna",
            "Password mora imati izmedju 7 i 20 karaktera, kao i sadržati i velike i mala slova kao i barem jedan broj",
            "Dva unesena passworda nisu jednaka!",
            "BitBucket SSH nije u validnom formatu!",
            "BitBucket URL nije u validnom formatu!",
            "Ime repozitorija nije u validnom formatu!",
            "Nastavna grupa koju ste napisali nije validna",
            "Indeks kojeg ste napisali nije validan",
            "Email koji ste napisali nije validan fakultetski email"];
    var porukeZaIspis=[];

    return{
        ERROR_IME_PREZIME: 0,
        ERROR_AKADEMSKA: 1,
        ERROR_NESIGURAN_PASSWORD: 2,
        ERROR_POTVRDA_PASSWORD: 3,
        ERROR_BB_SSH: 4,
        ERROR_BB_URL: 5,
        ERROR_REPO_NAME: 6,
        ERROR_NASTAVNA_GRUPA: 7,
        ERROR_INDEX: 8,
        ERROR_EMAIL: 9,

        ispisiGreske: function() {
            var str = "<ul>";
            for ( var i = 0; i < porukeZaIspis.length; ++ i ) {
                str += "<li>" + mogucePoruke[porukeZaIspis[i]] + "</li>"
            }
            str += "</ul>";

            var errorContainer = document.getElementById(idDivaPoruka);
            errorContainer.innerHTML = str;

            if ( porukeZaIspis.length === 0 ) {
                errorContainer.classList.add("hidden");
            } else {
                errorContainer.classList.remove("hidden");
            }

        },
        postaviIdDiva: function(divId) {
            idDivaPoruka = divId;
        },
        dodajPoruku: function(index) {
            var n = porukeZaIspis.indexOf(index);
            if ( n >= 0 ) return;
            porukeZaIspis.push(index)
        },
        ocistiGresku: function(index) {
            var n = porukeZaIspis.indexOf(index);
            if ( n < 0 ) return;
            porukeZaIspis.splice(n, 1);
        }
    }
}());
