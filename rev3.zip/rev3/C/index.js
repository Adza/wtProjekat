const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
app.use(express.static(__dirname));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

function checkPath(path) {
    if ( path.indexOf("/../") !== -1 ) {
        return false;
    }
    return true;
}


function param_error(res) {
    res.send(
        {
            "message": "Podaci nisu u traženom formatu!",
            "data": null
        }
    );
}



var routing = {
    "/downloadIzvjestaj":{
        get: function(req, res) {
            var requiredPrefix = "izvjestajS";
            var requiredPostfix = ".txt";

            if ( req.query.file === undefined ) {
                param_error(res);
                return;
            }


            var file = req.query.file;
            if ( file.substr(0, requiredPrefix.length) !== requiredPrefix ) {
                param_error(res);
                return;
            }

            if ( file.substr(file.length - requiredPostfix.length) !== requiredPostfix) {
                param_error(res);
                return;
            }

            if ( !checkPath(file) ) {
                param_error(res);
                return;
            }

            if ( !fs.existsSync(__dirname + "/" + file) ) {
                param_error(res);
                return;
            }

            res.download(__dirname + "/" + file);
        }
    },
    "/komentar": {
        post: function (req, res) {
            var fname = "markS" + req.body.spirala + "" + req.body.index + ".json";

            if ( !checkPath(fname) ) {
                param_error(res);
                return;
            }

            var sadrzajValidan = true;
            if ( req.body.sadrzaj.constructor !== Array ) {
                // nije niz
                sadrzajValidan = false;
            } else {
                req.body.sadrzaj.forEach(function (value) {
                    //provjeri da li svaki element niza ima trazene atribute

                    if ( value.sifra_studenta === undefined ||
                        value.tekst === undefined ||
                        value.ocjena === undefined ) {
                        sadrzajValidan = false;
                    }
                });
            }

            if ( sadrzajValidan === false
                || typeof(req.body.spirala) !== 'string'
                || typeof(req.body.index) !== 'string'
                || req.body.spirala.length === 0
                || req.body.index.length === 0 ) {

                param_error(res);
                return;
            }

            var content = JSON.stringify(req.body.sadrzaj);
            fs.writeFile(__dirname + "/" + fname, content, function() {
                res.send(JSON.stringify({
                    message: "Uspješno kreirana datoteka!",
                    data: req.body.sadrzaj
                }));
            });
        }
    },
    "/spisak": {
        post: function(req, res) {
            if ( req.body.spirala === undefined ||
                 req.body.spisak === undefined ) {
                param_error(res);
                return;
            }
            if ( ("" + req.body.spirala).trim().length === 0 ) {
                param_error(res);
                return;
            }

            if ( req.body.spisak.constructor !== Array ||
                req.body.spisak.length === 0 ) {
                param_error(res);
                return;
            }

            var fname = "spisakS" + req.body.spirala + ".json";
            if ( !checkPath(fname) ) {
                param_error(res);
                return;
            }

            fs.writeFile(__dirname + "/" + fname, JSON.stringify(req.body.spisak), function() {
                res.send(JSON.stringify({
                    message: "Uspješno kreirana datoteka!",
                    data: req.body.spisak.length
                }))
            });
        }
    },
    "/lista": {
        post: function(req, res) {
            if ( req.body.nizRepozitorija === undefined ||
                 req.body.godina === undefined ) {
                param_error(res);
                return;
            }

            var godina = req.body.godina;
            var nizRepozitorija = req.body.nizRepozitorija;


            var valid = true;

            if ( typeof(godina) !== 'string' || godina.length === 0 ) {
                valid = false;
            }

            if ( nizRepozitorija.constructor !== Array ) {
                valid = false;
            } else if ( nizRepozitorija.length === 0 ) {
                valid = false;
            }

            if ( valid === false ) {
                param_error(res);
                return;
            }

            var fname = "spisak" + godina + ".txt";
            if ( !checkPath(fname) ) {
                param_error(res);
                return;
            }

            fs.writeFileSync(__dirname + "/" + fname, "");

            var data = 0;
            for ( var i = 0; i < nizRepozitorija.length; ++ i ) {
                var url = nizRepozitorija[i];

                if ( url.indexOf(godina) === -1 ) {
                    continue; // todo provjeriti ovo sa ifritom
                }

                ++data;
                fs.appendFile(__dirname + "/" + fname, url + "\n");
            }

            res.send(JSON.stringify({
                message: "Lista uspješno kreirana",
                data: data
            }));
        }
    },
    "/izvjestaj": {
        post: function(req, res) {
            index = req.body.index;
            spirala = req.body.spirala;

            if ( typeof(index) !== 'string' || index.length === 0 ) {
                param_error(res);
                return;
            }

            var fname = "izvjestajS" + spirala + "" + index + ".txt";
            if ( !checkPath(fname) ) {
                param_error(res);
                return;
            }
            var fileSpisak = "spisakS" + spirala + ".json";
            if ( !checkPath(fileSpisak) ) {
                param_error(res);
                return;
            }
            var report = "";

            fs.readFile(__dirname + "/" + fileSpisak, function(error, data) {
                if ( error ) {
                    param_error(res);
                    return;
                }

                var spisak = JSON.parse(data);

                spisak.forEach(function (review) {
                    var reviewer = review[0];

                    for ( var j = 1; j < review.length; ++ j ) {
                        if ( review[j] !== index ) {
                            continue;
                        }

                        var ids = ["A", "B", "C", "D", "E"];
                        var str = "";
                        var arr = [];

                        if ( fs.existsSync(__dirname + "/markS" + spirala + "" + reviewer + ".json") ) {
                            str = fs.readFileSync(__dirname + "/markS" + spirala + "" + reviewer + ".json");
                            arr = JSON.parse(str);
                        }

                        var comment = "";
                        arr.forEach(function (value) {
                           if ( value.sifra_studenta !== ids[j] ) {
                               return;
                           }
                           comment = value.tekst;
                        });

                        report += comment + "\n##########\n";
                    }
                });

                fs.writeFileSync(__dirname + "/" + fname, report);

                res.send(JSON.stringify(
                {
                    message:"OK",
                    data:fname
                }));
            });
        }
    },
    "/bodovi": {
        post: function(req, res) {
            var index = req.body.index + "";
            var spirala = req.body.spirala + "";

            if ( typeof(index) !== 'string' || index.length === 0 ) {
                param_error(res);
                return;
            }
            if ( typeof(spirala) !== 'string' || spirala.length === 0 ) {
                param_error(res);
                return;
            }






            var fileSpisak = "spisakS" + spirala + ".json";
            if ( !checkPath(fileSpisak) ) {
                param_error(res);
                return;
            }
            var report = "";

            fs.readFile(__dirname + "/" + fileSpisak, function(error, data) {
                if ( error ) {
                    param_error(res);
                    return;
                }

                var spisak = JSON.parse(data);

                var sum = 0.0;
                var cnt = 0;

                spisak.forEach(function (review) {
                    var reviewer = review[0];

                    for ( var j = 1; j < review.length; ++ j ) {
                        if ( review[j] !== index ) {
                            continue;
                        }

                        var ids = ["A", "B", "C", "D", "E"];
                        var str = "";
                        var arr = [];

                        if ( fs.existsSync(__dirname + "/markS" + spirala + "" + reviewer + ".json") ) {
                            str = fs.readFileSync(__dirname + "/markS" + spirala + "" + reviewer + ".json");
                            arr = JSON.parse(str);
                        }

                        arr.forEach(function (value) {
                            if ( value.sifra_studenta !== ids[j] ) {
                                return;
                            }
                            sum += value.ocjena;
                            ++cnt;
                        });
                    }
                });

                var m = Math.floor(sum / cnt) + 1;


                res.send(JSON.stringify({
                    poruka: "Student " + index + " je ostvario u prosjeku " + m + " mjesto"
                }));

            });
        }
    }
};

var pageMappings = [
    {
        path: "login",
        file: 'login.html'
    },
    {
        path: 'unoskomentara',
        file: 'unoskomentara.html'
    },
    {
        path: 'statistika',
        file: 'statistika.html'
    },
    {
        path: "bitbucketPozivi",
        file: "bitbucketPozivi.html"
    },
    {
        path: "unosSpiska",
        file: "unosSpiska.html"
    },
    {
        path: "nastavnik",
        file: "nastavnik.html"
    }
];



pageMappings.forEach( function(value) {
    var fun = function (p) {
        app.get('/' + p.path, function (req, res) {
            res.sendFile(__dirname + '/' + p.file);
        });
    }(value);
});



for ( var key in routing ) {
    if ( !routing.hasOwnProperty(key) ) {
        continue;
    }

    var fun = function(r) {
        if (routing[key].post !== undefined) {
            app.post(key, function(req, res) {
                r.post(req, res);
            });
        }
        if (routing[key].get !== undefined) {
            app.get(key, function(req, res) {
               r.get(req, res);
            });
        }
    }(routing[key]);
}


app.listen(3000);

