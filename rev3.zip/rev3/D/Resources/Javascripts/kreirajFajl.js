var KreirajFajl = (function() {

  var kreirajKomentar = function(spirala, index, sadrzaj, fnCallback) {
    //Validiraj ulazne parametre ovdje
    if(spirala.length < 1 || index.length < 1 ) {
      fnCallback(-1, "Neispravni parametri");
      return;
    }

    //Ako su ok nastavi
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", 'komentar', true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    let data = { "spirala": spirala, "index": index, "sadrzaj": sadrzaj };
    let error = null;

    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        error = null;
      }
      else if (this.readyState == 4 && this.status >= 400) {
        error = this.status;
      }
      data = this.responseText;

      fnCallback(error, data);
    };

    xhttp.send(JSON.stringify(data));

  };

  var kreirajListu = function(godina, nizRepozitorija, fnCallback) {
    //Validiraj ulazne parametre ovdje
    if(godina.length < 1 || !(nizRepozitorija.constructor === Array) || nizRepozitorija.length < 1 ) {
      fnCallback(-1, "Neispravni parametri");
      return;
    }
    //Ako su ok nastavi
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", 'lista', true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    let data = { "godina": godina, "nizRepozitorija": nizRepozitorija };
    let error = null;

    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
        error = null;
      }
      else if(this.readyState == 4 && this.status >= 400) {
        error = this.status;
      }
      data = this.responseText;

      fnCallback(error, data);
    }

    xhttp.send(JSON.stringify(data));

  };

  var kreirajIzvjestaj = function(spirala, index, fnCallback) {
    //Validiraj ulazne parametre ovdje
    if(spirala.length < 1 || index.length < 1 ) {
      fnCallback(-1, "Neispravni parametri");
      return;
    }
    //Ako su ok nastavi
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", 'izvjestaj', true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    let data = { "spirala": spirala, "index": index };
    let error = null;

    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
        error = null;
      }
      else if(this.readyState == 4 && this.status >= 400) {
        error = this.status;
      }
      data = this.responseText;

      fnCallback(error, data);
    }

    xhttp.send(JSON.stringify(data));
  };

  var kreirajBodove = function(spirala, index, fnCallback) {
    //Validiraj ulazne parametre ovdje
    if(spirala.length < 1 || index.length < 1 ) {
      fnCallback(-1, "Neispravni parametri");
      return;
    }
    //Ako su ok nastavi
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", 'bodovi', true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    let data = { "spirala": spirala, "index": index };
    let error = null;

    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
        error = null;
      }
      else if(this.readyState == 4 && this.status >= 400) {
        error = this.status;
      }
      data = this.responseText;

      fnCallback(error, data);
    }

    xhttp.send(JSON.stringify(data));
  }

  return {
    kreirajKomentar: kreirajKomentar,
    kreirajListu: kreirajListu,
    kreirajIzvjestaj: kreirajIzvjestaj,
  }
})();