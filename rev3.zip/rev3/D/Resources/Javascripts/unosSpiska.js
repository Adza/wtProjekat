function obradiSpisak(e) {
  //Pokupi inpute
  let tekst = e.textarea_spisak.value.split('\n').map(x => x.split(','));
  let broj = e.counter.value;
  let poruka_div = document.getElementById('poruka-spiska');
  //validiraj podatke
  let validno = true;
  if(!broj || parseInt(broj) < 1) {
    poruka_div.innerHTML = "Nije odabran validan broj spirale!";
    return;
  }
  for(let i= 0; i < tekst.length; i++) {
    if(tekst[i].length != 6) {
      poruka_div.innerHTML = (i + 1) + ". red nema tacan broj elemenata!";
      validno = false;
      break;
    }

    for(let j = 0; j < tekst[i].length; j++) {
      if(!Validacija.validirajIndex(tekst[i][j])) {
        poruka_div.innerHTML = (j + 1) + ". indeks u " + (i + 1) + ". redu nije validan!";
        validno = false;
        break;
      }
    }
    if(!validno) {
      break;
    }
  }
  if(!validno) {
    return;
  }
  poruka_div.innerHTML = "";
  //parsiraj i salji
  let xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if(this.readyState == 4 && this.status == 200) {
      poruka_div.innerHTML = "Spisak uspjesno kreiran!!";
    }
    else {
      poruka_div.innerHTML = "Greska na serveru!";
    }
  }
  xhttp.open("POST", 'unesispisak', true);
  xhttp.setRequestHeader("Content-Type", "application/json");
  xhttp.setRequestHeader("broj_spirale", broj);
  xhttp.send(JSON.stringify(tekst));
}