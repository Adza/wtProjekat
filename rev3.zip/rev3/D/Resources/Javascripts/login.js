var dugmeRegistrujNastavnika = document.getElementById('registruj-nastavnika');
var dugmeRegistrujStudenta = document.getElementById("registruj-studenta");
var formaNastavnik = document.getElementById("registracija-nastavnik");
var formaStudent = document.getElementById("registracija-student");
var greskeStudent = document.getElementById("greske-student");
var greskeNastavnik = document.getElementById("greske-nastavnik");



dugmeRegistrujStudenta.addEventListener("click", function() {

	formaNastavnik.style.display= 'none';
	greskeNastavnik.style.display= 'none';
	document.getElementById('forma').reset();
	greskeNastavnik.innerHTML="";

	formaStudent.style.display= 'block';
	greskeStudent.style.display= 'block';
	Poruke.postaviIdDiva('greske-student');
});

dugmeRegistrujNastavnika.addEventListener("click", function() {
	formaNastavnik.style.display = "block";
	greskeNastavnik.style.display= "block";

	formaStudent.style.display= 'none';
	greskeStudent.style.display= 'none';
	document.getElementById('forma').reset();
	greskeStudent.innerHTML="";

	Poruke.postaviIdDiva('greske-nastavnik');
});

function handleError(validation_successfull, message_index) {
	if(validation_successfull) {
		Poruke.ocistiGresku(message_index);
	}
	else {
		Poruke.dodajPoruku(message_index);
	}

	Poruke.ispisiGreske();
}