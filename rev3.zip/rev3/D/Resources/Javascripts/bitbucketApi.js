var BitbucketApi = (function() {

  var dohvatiAccessToken = function(key, secrert, fnCallback) {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
        fnCallback(null, JSON.parse(this.responseText).access_token);
      }
      else if(this.readyState == 4 && this.status >= 400) {
        fnCallback(this.status, this.responseText);
      }
    };

    xhttp.open("POST", "https://bitbucket.org/site/oauth2/access_token",  true );
    xhttp.setRequestHeader('Content-Type', "application/x-www-form-urlencoded");
    xhttp.setRequestHeader("Authorization", 'Basic ' + btoa(key + ":" + secrert));
    xhttp.send("grant_type=" + encodeURIComponent( "client_credentials" ));
  }


  var dohvatiRepozitorije = function(token, godina, naziv, branch, fnCallback) {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {

        let response = JSON.parse(this.responseText);

        response.values = response.values.filter(function(repo) {
          return repo.created_on.substring(0,4) == godina || repo.created_on.substring(0,4) == (parseInt(godina) + 1);
        });

        fnCallback(null, response);
      }
      else {
        fnCallback(this.status, this.responseText);
      }
    }

    //Ovo ce isfiltrirati po nazivu
    xhttp.open("GET", "https://api.bitbucket.org/2.0/repositories?role=member&pagelen=150&q=name" + encodeURIComponent('~"') + naziv + encodeURIComponent('"'));
    xhttp.setRequestHeader("Authorization", 'Bearer ' + token );
    xhttp.send();

  };

  var dohvatiBranch = function(token, url, naziv, fnCallback) {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if(this.readyState == 4 && this.status == 200) {
        let response = JSON.parse(this.responseText);
        response.values = response.values.filter(function(branch) {
          return branch.name == naziv;
        });

        fnCallback(null, response.values.length > 0);
      }
      else {
        fnCallback(this.status, this.responseText);
      }
    };

    xhttp.open("GET", url, true);
    xhttp.setRequestHeader("Authorization", 'Bearer ' + token );
    xhttp.send();
  };

  return {
    dohvatiAccessToken: dohvatiAccessToken,
    dohvatiRepozitorije: dohvatiRepozitorije,
    dohvatiBranch: dohvatiBranch
  }

})();