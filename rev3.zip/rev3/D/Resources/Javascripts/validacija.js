var Validacija = (function() {
  var maxGrupa = 7;
  var trenutniSemestar=0; // 0 za zimski, 1 za ljetni

  //funkcije
  var validirajFakultetski = function(email) {
    let regex = /^[a-z0-9._]{1,64}@etf\.unsa\.ba$/;
    return regex.test(email);
  };

  var validirajIndex = function(index) {
    let regex = /^1[0-9]{4}/;
    return regex.test(index);
  };

  var validirajGrupu = function(grupa) {
    return (grupa >= 1 && grupa <= maxGrupa);
  };

  var validirajAkGod = function(godina) {
    let regex = /^20[0-9]{2}\/20[0-9]{2}$/;
    if(regex.test(godina)) {
      let godina1 = parseInt((/^[0-9]{4}/).exec(godina));
      let godina2 = parseInt((/[0-9]{4}$/).exec(godina));

      if(godina1 != godina2 - 1) {
        return false;
      }

      if(trenutniSemestar) {
        return godina2 == new Date().getFullYear();
      }
      else {
        return godina1 == new Date().getFullYear();
      }
    }
    else {
      return false;
    }
  };

  var validirajPassword = function(password) {
    let regex = /^(?=\w{7,20}$)(?=[^0-9]*[0-9])(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z])/;
    return regex.test(password);
  };

  var validirajPotvrdu = function(password, password_potvrda) {
    return validirajPassword(password) && password === password_potvrda;
  };

  var  validirajBitbucketURL = function(url) {
    let regex = /^https:\/\/\w*@bitbucket\.org\/\w*\/\w*\.git$/i;
    return regex.test(url);
  };

  var validirajBitbucketSSH = function(ssh) {
    let regex = /^git@bitbucket\.org:\w*\/\w*\.git$/i;
    return regex.test(ssh);
  };

  var validirajNazivRepozitorija = function(regex, naziv) {
    if(regex == null) {
      let defaut_regex = /^wt[Pp]rojekat1[0-9]{4}$/;
      return defaut_regex.test(naziv);
    }
    else {
      return regex.test(naziv);
    }
  };

  var validirajImeiPrezime = function(ime_prezime) {
    let regex = /^[A-ZČĆŽŠĐ][a-zA-z'-ČčĆćŽžŠšĐđ]{2,11} [A-ZČĆŽŠĐ][a-zA-z'-ČčĆćŽžŠšĐđ]{2,11}/;
    return regex.test(ime_prezime);
  };

  var postaviMaxGrupa = function(max_grupa) {
    if(max_grupa < 1) {
      console.log("Maksimalni broj grupa mora biti pozitivan!");
      return;
    }
    else {
      maxGrupa = max_grupa;
    }
  };

  var postaviTrenSemestar = function(trenutni) {
    if(trenutni < 0 || trenutni > 1) {
      console.log("Dozvoljene vrijednosti su 0 i 1!");
      return;
    }
    else {
      trenutniSemestar = trenutni;
    }
  };

  return {
    validirajFakultetski: validirajFakultetski,
    validirajIndex: validirajIndex,
    validirajGrupu: validirajGrupu,
    validirajAkGod: validirajAkGod,
    validirajPassword: validirajPassword,
    validirajPotvrdu: validirajPotvrdu,
    validirajBitbucketURL: validirajBitbucketURL,
    validirajBitbucketSSH: validirajBitbucketSSH,
    validirajNazivRepozitorija: validirajNazivRepozitorija,
    validirajImeiPrezime: validirajImeiPrezime,
    postaviMaxGrupa: postaviMaxGrupa,
    postaviTrenSemestar: postaviTrenSemestar
  }
    }
());