function getPage(page_name) {
  let xhttp = new XMLHttpRequest();
  xhttp.open("GET", page_name, true);
  xhttp.setRequestHeader("Content-Type", "text/html");
  xhttp.onreadystatechange = function() {
    if(this.readyState == 4 && this.status == 200) {
      document.getElementById("main-container").innerHTML = this.responseText;
    }
  }
  xhttp.send();
}