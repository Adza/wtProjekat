var Poruke= (function() {
  var idDivaPoruke;
  var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email", "Indeks kojeg ste napisali nije validan",
  "Nastavna grupa koju ste napisali nije validna", "Akademska godina koju ste napisali nije validna", "Password koji ste unijeli nije validan",
   "Potvrda passworda nije prosla", "Bitbucket url koji ste unijeli nije validan", "Bitbucket ssh kojeg ste unijeli nije  validan",
   "Naziv repozitorija koji ste unijeli nije validan", "Ime i prezime koje ste unijeli nije validno"];

   var porukeZaIspis=[];

   var ispisiGreske = function() {
    let div = document.getElementById(idDivaPoruke);
    div.innerHTML = "";
    for(let i=0; i < porukeZaIspis.length; i++) {
      div.innerHTML+= porukeZaIspis[i];
      if(i < porukeZaIspis.length - 1) {
        div.innerHTML+=', ';
      }
    }
   };

   var postaviIdDiva = function(id) {
    idDivaPoruke = id;
    porukeZaIspis=[];
   };

   var dodajPoruku = function(index) {
    if(index < 0 || index >= mogucePoruke.length) {
      console.log("Indeks izvan opsega");
      return;
    }

    let i = porukeZaIspis.indexOf(mogucePoruke[index]);
    if(i != -1) {
      console.log("Poruka je vec unijeta");
      return;
    }


    porukeZaIspis.push(mogucePoruke[index]);
   };

   var ocistiGresku = function(index) {
    if(index < 0 || index >= mogucePoruke.length) {
      console.log("Indeks izvan opsega");
      return;
    }
    let i = porukeZaIspis.indexOf(mogucePoruke[index]);
    if(i != -1) {
      porukeZaIspis.splice(i, 1);
    }
   };

   return {
    ispisiGreske: ispisiGreske,
    postaviIdDiva: postaviIdDiva,
    dodajPoruku: dodajPoruku,
    ocistiGresku: ocistiGresku
   }

}());


Poruke.postaviIdDiva('greske-student');