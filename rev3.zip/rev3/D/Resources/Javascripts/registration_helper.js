//Student

function validirajIme(input_id) {
  let studentIme = document.getElementById(input_id);

  handleError(Validacija.validirajImeiPrezime(studentIme.value),9);
}

function validirajMail(input_id) {
  let studentMail = document.getElementById(input_id);

  handleError(Validacija.validirajFakultetski(studentMail.value), 0);
}


function studentValidirajIndeks() {
  let studentIndeks = document.getElementById('indeks');
  handleError(Validacija.validirajIndex(studentIndeks.value), 1);
}

function studentValidirajGrupu() {
  let studentGrupa = document.getElementById('nastavna-grupa');
  handleError(Validacija.validirajGrupu(studentGrupa.value), 2);
}

function validirajGodinu(input_id) {
  let studentGodina = document.getElementById(input_id);
  handleError(Validacija.validirajAkGod(studentGodina.value), 3);
}

function validirajPassword(input_id) {
  let studentPass = document.getElementById(input_id);
  handleError(Validacija.validirajPassword(studentPass.value), 4);
}

function passConfirm(input1_id, input2_id) {
  let studentPass = document.getElementById(input1_id);
  let studentPass2 = document.getElementById(input2_id);
  handleError(Validacija.validirajPotvrdu(studentPass.value, studentPass2.value), 5);
}

function studentBbUrl() {
  let studentBB = document.getElementById('bitbucket-url');
  handleError(Validacija.validirajBitbucketURL(studentBB.value), 6);
}

function studentBBbsh() {
  let studentBbS = document.getElementById('bitbucket-ssh');
  handleError(Validacija.validirajBitbucketSSH(studentBbS.value), 7);
}

function studentRepo() {
  let repo = document.getElementById('repo-name');
  handleError(Validacija.validirajNazivRepozitorija(null, repo.value), 8);
}