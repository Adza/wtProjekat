function pushUp(e){
	let currentRow = e.parentNode.parentNode;

	if(currentRow.rowIndex == 0){
		return;
	}
	else{
		let previouschild = currentRow.parentNode.rows[ currentRow.rowIndex - 1 ];
		let temp = previouschild.innerHTML;
		previouschild.innerHTML = currentRow.innerHTML;
		currentRow.innerHTML = temp;
	}


}

function pushDown(e){
	let currentRow = e.parentNode.parentNode;
	if(currentRow.rowIndex == currentRow.parentNode.rows.length - 1) {
		return;
	}
	else
	{
		let nextchild = currentRow.parentNode.rows[ currentRow.rowIndex + 1 ];
		let temp = nextchild.innerHTML;
		nextchild.innerHTML = currentRow.innerHTML;
		currentRow.innerHTML = temp;
	}
}

//vrati poziciju reda u tabeli
function brojDiva(id){
  var elementdiv = document.getElementById(id);
  var i = 0;
  while(elementdiv.previousElementSibling != null){
    elementdiv = elementdiv.previousElementSibling;
    i++;
  }
  return i;
}


function procesiraj() {
	let data = [];
	mojIndeks = document.getElementById('mojIndeks').value;
	broj = document.getElementById('brojSpirale').value;
	for(let i = 0; i < 5; i++) {
		let ocjena = brojDiva("red-studenta-" + i);
		let sifra = document.getElementById('sifra-studenta-' + i).innerHTML;
		let tekst = document.getElementById('komentar-' + i).value;

		data.push({ "sifra": sifra, "tekst": tekst, "ocjena": ocjena });
	}

	let xhttp = new XMLHttpRequest();
	xhttp.open("POST", 'komentar', true);
	xhttp.onreadystatechange = function() {
		if(this.status == 200 && this.readyState == 4) {
		}
		else {
		}
	}
	xhttp.setRequestHeader("Content-Type", "application/json");
	xhttp.setRequestHeader("broj_spirale", broj);
	xhttp.setRequestHeader("broj_indeksa", mojIndeks);
	xhttp.send(JSON.stringify(data));
}

