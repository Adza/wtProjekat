const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const port = 3000;
const fs = require('fs');
const app = express();


//Static paths
app.use(express.static('Resources'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

app.set('view engine', 'ejs');
app.set('views', 'views');

//root
app.get('/', function(req, res) {
  res.render('index');
});


//login
app.get('/login', function(req, res) {
	res.render('partials/login', { layout: false });
});

//unoskomentara
app.get('/unoskomentara', function(req, res) {
	res.render('partials/unoskomentara', { layout: false });
});

//statistika
app.get('/statistika', function(req, res) {
	res.render('partials/statistika', { layout: false });
});

//unesi spisak partial
app.get('/unosspiska', function(req, res) {
	res.render('partials/unosSpiska', { layout: false});
});

//nastavnik partial
app.get('/nastavnik', function(req, res) {
	res.render('partials/nastavnik', { layout: false});
});

//bitbucket partial
app.get('/bitbucket', function(req, res) {
	res.render('partials/bitbucketPozivi', { layout: false});
});

//post za unos spiska
app.post('/unesispisak', function(req, res) {
	let broj_spirale = req.get('broj_spirale');
	let imeDokumenta = "spisakS" + broj_spirale + ".json";
	fs.writeFile(imeDokumenta, JSON.stringify(req.body, null, 2), function(error) {
		if(error) {
			res.status(500).send({ error: 'Greska!!' });
		}
	});
	res.send('Alles wird gut!');
	console.log('proslo');
});

//komentar
app.post('/komentar', function(req, res) {
	console.log(req.body);
	let index = req.get('broj_indeksa');
	let broj_spirale = req.get('broj_spirale');
	let imeDokumenta = "mark" + broj_spirale + index + ".json";
	fs.writeFile(imeDokumenta, JSON.stringify(req.body, null, 2), function(error) {
		if(error) {
			res.status(500).send({ error: 'Greska!!' });
		} else {
			res.send("OK");
		}
	});
	console.log('proslo');
});

app.listen(port, function() {
  console.log('Server running on port ' + port);
});