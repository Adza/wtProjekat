const
        express = require('express'),
        bodyParser = require('body-parser'),
        fs = require('fs');

const
        app = express();


app.use(bodyParser.urlencoded({
    extended:true
}));
app.use(bodyParser.json());

app.use(express.static('public'));

app.set('PORT', (process.env.PORT || 3000));


app.get('/', (req, res) => {
    res.sendFile('index.html');
});

app.get('/:stranica', (req, res) => {

    fs.readFile(__dirname +'/public/'+ req.params.stranica + '.html', 'utf8', (err, content) => {
        if(err) return;

        res.end(content);
    })
});


function validacijaSadrzaj(sadrzaj)
{
    for(var i=0;i<sadrzaj.length;i++)
    {
        if(sadrzaj[i].length!=3&&!sadrzaj[i].hasOwnProperty("‘sifra_studenta")&&!sadrzaj[i].hasOwnProperty("tekst")&&!sadrzaj[i].hasOwnProperty("ocjena"))
        return false;
        
    }
    return true;

}


app.post('/komentar', function(req, res){
    
    if(req.body.spirala.length>0&&req.body.index.length>0&&validacijaSadrzaj(req.body.sadrzaj))
    {
        let json = JSON.stringify(req.body.sadrzaj,null,2);
        fs.writeFile(__dirname + '/markS' + req.body.spirala + req.body.index + '.json', 
        json,
        (err) => {
            if(err) 
                throw err;
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({message:'Uspjesno kreirana datoteka!', data: req.body.sadrzaj}));
        });
    }
    else
    {
        res.end(JSON.stringify({message:'Pogresan format', data:null}));
        
    }
        
    
});


app.post('/lista', function(req, res){
    
    if(req.body.godina.length>0&&req.body.nizRepozitorija.length>0)
    {
        var repozitoriji=req.body.nizRepozitorija;
        var ispis=repozitoriji.join().split(',').join('\n');


        fs.writeFile(__dirname + '/spisak' + req.body.godina+ '.txt', 
        ispis,
        (err) => {
            if(err) 
                throw err;
            res.writeHead(200, {'Content-Type': 'application/json'});
            res.end(JSON.stringify({message:'Lista uspjesno kreirana!', data: req.body.sadrzaj}));
        });
    }
    else
    {
        res.end(JSON.stringify({message:'Pogresan format', data:null}));
        
    }
        
    
});

app.post('/izvjestaj', function(req, res){
    
      if( !req.body.spirala.length>1 || !req.body.index.length>1 ) return res.status(500).send({ message: "Pogresan format" })
    
      fs.readdir('./', function(err, files)
      {
        if( err ) 
            return res.status(500).send(err)

        let kom = [];
        let kodStudenta = [ "A", "B", "C", "D", "E" ];

        if( files.indexOf( "spisakS"+req.body.spirala + ".json" ) > -1 )
        {
    
          fs.readFile( __dirname + "/" + "spisakS"+req.body.spirala + ".json", function( err, indexi ){
            if( err )
                return res.status(500).send(err);
    
            indexi = JSON.parse(indexi);
            indexi.map( function( indexRow ){
              let temp = indexRow.indexOf( req.body.index );
              if( temp > 0 ){
                kom.push({
                  index: indexRow[0],
                  sifra: kodStudenta[ temp - 1 ],
                  visited: null,
                })
              }
            } )
    
            if(kom.length == 0) 
                return res.status(500).send( { message: "Trazeni index ne postoji " + req.body.index } )
    
    
            let komentari = "";
    
            kom.map( function(value, ind){
              fs.readFile( __dirname + '/markS' + req.body.spirala + value.index + ".json", function(err, comments){
                kom[ind].visited = true;
                if( err )
                {
                  komentari += '\n';
                }
                else
                {
                  comments = JSON.parse(comments);
                  let v = comments.find( function( comment ){
                    return comment.sifra_studenta == value.sifra;
                  } )
                  if(v)
                  {
                      komentari+='##########\n'+v.tekst+'\n';
                  }
                  else
                  {
                      komentari+='\n';
                  }
                }
    
                if( kom.find( function( c ){
                  return c.visited == null
                } ) ) return;
                
                if(komentari[komentari.length-1]=='\n')
                {
                    komentari=komentari.slice(0,-1);
                }
                else
                {
                    komentari=komentari;
                }

                fs.writeFile( 'izvjestajS' + req.body["spirala"] + req.body["index"] + ".txt", komentari, function( err, data ){
                  if( err ) 
                    res.status(500).send(err);
    
                  let value = __dirname + '/izvjestajS' + req.body["spirala"] + req.body["index"] + ".txt"
                  return res.status(200).sendFile(value);
                } )
    
    
    
              } )
            } )
    
          } )
    
        }else {
          return res.status(500).send( { message: "Fajl " + "spisakS"+req.body.spirala + ".json" + " ne postoji", data: null } )
        }
    
    
      })
    })




 app.post('/unosSpiska', function(req, res){
    fs.writeFile(__dirname + '/spisakS' + req.body.spirala + '.json', req.body.unos, (err) => {
        if(err) {
            throw err;
        }
        res.writeHead(200, {'Content-Type': 'application/json'});
        res.end(JSON.stringify({message:'Uspjesan unos', data: req.body.unos}));
    })
});
 



app.listen(app.get('PORT'), 'localhost', () => {
    console.log('Server is running...');
});
