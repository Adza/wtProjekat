function SubmitButton(){
    
    var unos=document.getElementById("unosTekst").value;
    var spirala= document.getElementById("spirSpis").value;
    var greske=document.getElementById("greskeSpisak");
    var redovi=unos.split('\n');
    var pregledaju=[];
    //validacija
    for(var i=0;i<redovi.length;i++)
    {
        var red=redovi[i].split(',');
        if(red.length!=6)
        {
            greske.innerHTML="red "+(i+1)+' nema 6 elemenata';
            return;
        }
        for(var j=0;j<red.length;j++)
        {
            for(var k=j+1;k<red.length;k++)
            {
                if(red[j]==red[k])
                {
                    greske.innerHTML="red "+(i+1)+' ima dupli indeks';
                    return;
                }
            }
        }
        pregledaju.push(red[0]);
    }
    if(spirala<1||spirala>4)
    {
        greske.innerHTML="spirala nije uredu";
        return;
    }



    var ajax = new XMLHttpRequest();
    
            var posalji = [];
    
            for(let i = 0; i < redovi.length; i++) {
                let red = redovi[i].split(',');
                posalji.push(red);
            }


            ajax.onreadystatechange=function(){
                if(ajax.readyState == 4 && ajax.status == 200)
                {
                    spirala.value = "";
                    unos.value = "";
                    greske.innerHTML = JSON.parse(ajax.responseText).message;
                }
                else
                {
                    greske.value= JSON.parse(ajax.status);
                }
            }

            posalji = JSON.stringify(posalji,null,2);
            ajax.open('POST', 'http://localhost:3000/unosSpiska', true);
            ajax.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            ajax.send("spirala=" + encodeURIComponent(spirala) + "&unos=" + encodeURIComponent(posalji));


   

}