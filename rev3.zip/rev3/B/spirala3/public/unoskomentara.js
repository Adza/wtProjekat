function Gore(dugme)
{
    var red=dugme.parentNode.parentNode;
    var redPrije=red.previousElementSibling;
    if(red.rowIndex!=1)
    red.parentNode.insertBefore(red,redPrije);

}

function Dole(dugme)
{
    var red=dugme.parentNode.parentNode;
    var redPoslije=red.nextElementSibling;
    if(redPoslije!=null)
    red.parentNode.insertBefore(red,redPoslije.nextElementSibling);
    
}