function loadContent(link)
{
  let ajax = new XMLHttpRequest();

  ajax.onreadystatechange = function() {
      if(ajax.readyState === 4 && ajax.status === 200) {

          let content = document.getElementById('kontejner');

          content.innerHTML = ajax.responseText;
      }
  }
  switch(link.id) {
      case "login":
          ajax.open('GET', 'http://localhost:3000/login', true);
      break;
      case "statistika":
          ajax.open('GET', 'http://localhost:3000/statistika', true);
      break;
      case "unoskomentara":
          ajax.open('GET', 'http://localhost:3000/unoskomentara', true);
      break;
      case "unosSpiska":
      ajax.open('GET', 'http://localhost:3000/unosSpiska', true);
  break;
      default:
          throw new DOMException("Error");
  }
  ajax.send();
}
