window.onload = function(){
   // gasiNastavnikove();
    //Cisti();
 };

function pocetak()
{
    gasiNastavnikove();
    Cisti();
}

function gasiNastavnikove()
{
    document.getElementById("korIme").style.display="none";
    document.getElementById("maill").style.display="none";
    document.getElementById("maxGrupa").style.display="none";
    document.getElementById("regRepo").style.display="none";
    document.getElementById("tSem").style.display="none";
}
function VratiNastavnikove()
{
    document.getElementById("korIme").style.display="block";
    document.getElementById("maill").style.display="block";
    document.getElementById("maxGrupa").style.display="block";
    document.getElementById("regRepo").style.display="block";
    document.getElementById("tSem").style.display="block";
}
function gasiStudentove()
{
    document.getElementById("indeks").style.display="none";
    document.getElementById("grupe").style.display="none";
    document.getElementById("bitUrl").style.display="none";
    document.getElementById("bitSsh").style.display="none";
    document.getElementById("nazivRepo").style.display="none";
}
function VratiStudentove()
{
    document.getElementById("indeks").style.display="block";
    document.getElementById("grupe").style.display="block";
    document.getElementById("bitUrl").style.display="block";
    document.getElementById("bitSsh").style.display="block";
    document.getElementById("nazivRepo").style.display="block";
}
function Cisti()
{
    document.getElementById("imePrez").value="";
    document.getElementById("pass").value="";
    document.getElementById("pasCon").value="";
    document.getElementById("akGodina").value="";

    document.getElementById("indeks").value="";
    document.getElementById("bitUrl").value="";
    document.getElementById("bitSsh").value="";
    document.getElementById("nazivRepo").value="";
    document.getElementById("korIme").value="";
    document.getElementById("maill").value="";
    document.getElementById("maxGrupa").value="";
    document.getElementById("regRepo").value="";
    document.getElementById("tSem").value="";
    var greske = document.getElementById("ListaPoruka");

    if (greske) {
        while (greske.firstChild) {
          greske.removeChild(greske.firstChild);
        }
      }

      for(var g=0;g<10;g++)
      {
          Poruke.obrisiPoruku(g);
      }
}



function RegNastavnikButton(){
    document.getElementById("h2Reg").textContent="Registruj Nastavnika";
    gasiStudentove();
    VratiNastavnikove();
    Cisti();

};

function RegStudentButton(){
    document.getElementById("h2Reg").textContent="Registruj Studenta";
    gasiNastavnikove();
    VratiStudentove();
    Cisti();
}




var Validacija=(function(){

    var maxGrupa=7;
    var trenutniSemestar=0;

    function validirajIndex(indeks){
        return /^(1\d\d\d\d)$/.test(indeks);
    }
    function validirajFakultetski(mail){
        return /[a-z][a-z|\d]*@etf.unsa.ba/.test(mail);
    }

    function validirajSemestar(sem)
    {
        if((sem=="Zimski"&&trenutniSemestar==0)||(sem=="Ljetni"&&trenutniSemestar==1))
        return true;
        else
        return false;
    }

    function validirajGrupu(grupa){
        if(grupa>=1&&grupa<=maxGrupa)
            return true;
        else
            return false;
    }

    function validirajAkGod(god){
        if(god.length!=9)
        {
            return false;
        }
        {
            var res = god.slice(0, 4);
            var res2=god.slice(5,9);

            var god1=Number(res);
            var god2=Number(res2);

            if(god1+1==god2 && /20[0-9][0-9]\/20[0-9][0-9]$/.test(god))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }

    function validirajPassword(pas){
        if(/.*[0-9].*/.test(pas)&&/.*[a-z].*/.test(pas)&&/.*[A-Z].*/.test(pas)&&pas.length>=7&&pas.length<=20)
            return true;
        else
            return false;
    }

    function validirajPotvrdu(s1,s2){
        if(s1==s2&&validirajPassword(s1)&&validirajPassword(s2))
        return true;
        else
        return false;
    }

    function validirajBitbucketURL(link){
        var regeks1=/^https:\/\//;
        var regeks2=/.git$/;
        var regeks3=/^\b[a-z0-9]+\b$/;
        if(regeks1.test(link)&&regeks2.test(link))
        {

            var pozicija=link.indexOf("@");
            var username1 = link.slice(8, pozicija);
            var pozicija2=link.indexOf("/",pozicija);
            var bitbuck=link.slice(pozicija,pozicija2);
            if(bitbuck!="@bitbucket.org")
                return false;
            var pozicija3=link.indexOf("/",pozicija2+1);
            var username2=link.slice(pozicija2+1,pozicija3);
            if(username1!=username2)
                return false;

            var pozicija4=link.indexOf(".git",pozicija3);
            var repo=link.slice(pozicija3+1,pozicija4);
            if(regeks3.test(username1)&&validirajNazivRepozitorija(null,repo))
                return true;
            else
                return false;
        }
        return false;





    }
    function validirajBitbucketSSH(ssh){

        var regeks1=/^git@bitbucket.org:/;
        var regeks2=/.git$/;
        var regeks3=/^\b[a-z0-9]+\b$/;

        if(regeks1.test(ssh)&&regeks2.test(ssh))
        {

            var pozicija=ssh.indexOf(":");
            var pozicija2=ssh.indexOf("/");
            var username1=ssh.slice(pozicija+1,pozicija2);


            var pozicija3=ssh.indexOf(".git");
            var repo=ssh.slice(pozicija2+1,pozicija3);



            if(regeks3.test(username1)&&validirajNazivRepozitorija("",repo))
                return true;
            else
                return false;
        }
        return false;

    }

    function validirajNazivRepozitorija(repoRegex,repo){
        if(repoRegex=="")
        {
           return (/wtProjekat1[0-9]{4}/.test(repo)||/wtprojekat1[0-9]{4}/.test(repo));
        }
        else
        {
            return repoRegex.test(repo);
        }
    }

    function validirajImeiPrezime(ime){
        var regeks=/^([A-ZČĆĐŠŽ][a-zčćđšž\-']*((-|'|\s)[A-ZČĆĐŠŽ][a-zčćđšž]*)*)$/g;
        var res = ime.split(" ");
        if(regeks.test(ime))
        {
            for(var r=0;r<res.length;r++)
            {
                if(res[r].length<=12&&res[r].length>=3)
                return true;
            }
            return false;
        }
        return false;

    }

    return{
        validirajIndex: validirajIndex,
        validirajFakultetski:validirajFakultetski,
        validirajGrupu:validirajGrupu,
        validirajAkGod:validirajAkGod,
        validirajPassword:validirajPassword,
        validirajPotvrdu:validirajPotvrdu,
        validirajBitbucketURL:validirajBitbucketURL,
        validirajBitbucketSSH:validirajBitbucketSSH,
        validirajNazivRepozitorija:validirajNazivRepozitorija,
        validirajImeiPrezime:validirajImeiPrezime,
        validirajSemestar:validirajSemestar
    }


}());


function validacijaTrenutniSemestar()
{
    if(!Validacija.validirajSemestar(document.getElementById('tSem').value))
    {
        Poruke.dodajPoruku(9);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(9);
        Poruke.ispisiGreske();
    }
}

function validacijaIme(){
    if(!Validacija.validirajImeiPrezime(document.getElementById('imePrez').value))
    {
        Poruke.dodajPoruku(0);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(0);
        Poruke.ispisiGreske();
    }
}
function validacijaIndeks(){
    if(!Validacija.validirajIndex(document.getElementById('indeks').value))
    {
        Poruke.dodajPoruku(1);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(1);
        Poruke.ispisiGreske();
    }
}

function validacijaMail(){
    if(!Validacija.validirajFakultetski(document.getElementById('maill').value))
    {
        Poruke.dodajPoruku(8);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(8);
        Poruke.ispisiGreske();
    }
}
function validacijaAkademska(){
    if(!Validacija.validirajAkGod(document.getElementById('akGodina').value))
    {
        Poruke.dodajPoruku(2);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(2);
        Poruke.ispisiGreske();
    }
}

function validacijaPass(){
    if(!Validacija.validirajPassword(document.getElementById('pass').value))
    {
        Poruke.dodajPoruku(3);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(3);
        Poruke.ispisiGreske();
    }
}

function validacijaPassPotvrda(){
    if(!Validacija.validirajPotvrdu(document.getElementById('pass').value,document.getElementById('pasCon').value))
    {
        Poruke.dodajPoruku(4);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(4);
        Poruke.ispisiGreske();
    }
}

function validacijaBitUrl(){
    if(!Validacija.validirajBitbucketURL(document.getElementById('bitUrl').value))
    {
        Poruke.dodajPoruku(5);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(5);
        Poruke.ispisiGreske();
    }
}
function validacijaBitSsh(){
    if(!Validacija.validirajBitbucketSSH(document.getElementById('bitSsh').value))
    {
        Poruke.dodajPoruku(6);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(6);
        Poruke.ispisiGreske();
    }
}

function validacijaNazivRepo(){
    if(!Validacija.validirajNazivRepozitorija(document.getElementById('regRepo').value,document.getElementById('nazivRepo').value))
    {
        Poruke.dodajPoruku(7);
        Poruke.ispisiGreske();
    }
    else
    {
        Poruke.obrisiPoruku(7);
        Poruke.ispisiGreske();
    }
}
