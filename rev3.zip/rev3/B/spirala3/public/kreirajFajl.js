var KreirajFajl=(function(){

    function provjeri(niz, format){
		for(let i = 0; i<niz.length; i++){
			for(let obj in niz[i]){
				if(format.indexOf(obj) == -1) return false;
			}
		}
		return true;
	}


    return {
        kreirajKomentar = function(spirala, index, sadrzaj, fnCallback){
            if(spirala.length>0&&index.length>0&&provjeri(sadrzaj,['sifra_studenta','tekst','ocjena']))
            {
                var ajax=new XMLHttpRequest();

                ajax.onreadystatechange=function(){
                    if(ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null, this.responseText);
                    }
                    else
                    {
                        fnCallback(this.status, this.responseText);
                    }
                        
                    ajax.open("POST", "http://localhost:3000/komentar", true);
                    ajax.setRequestHeader("Content-type", "application/json");
                    ajax.send(JSON.stringify(
                        {
                          spirala: spirala,
                            index: index,
                            sadrzaj: sadrzaj
                      }
                    ))
                }
            }
            else
            {
                fnCallback(-1,"Neispravni parametri");
                return;
            }

            
        },
        kreirajListu = function(godina, nizRepozitorija, fnCallback){
            if(godina.length>0&&nizRepozitorija.length>0&&nizRepozitorija[0].length>0)
            {
                var ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    if(ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null, this.responseText);
                    }
                    else
                    {
                        fnCallback(this.status, this.responseText);
                    }
                        
                    ajax.open("POST", "http://localhost:3000/lista", true);
                    ajax.setRequestHeader("Content-type", "application/json");
                    ajax.send(JSON.stringify(
                        {
                          godina: godina,
                          nizRepozitorija: nizRepozitorija
                      }
                    ))
                }
            }
            else
            {
                fnCallback(-1,"Neispravni parametri");
                return;
            }
        },
        kreirajIzvjestaj = function(spirala,index, fnCallback){
            if(index.length>0&&spirala.length>0)
            {
                var ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    if(ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null, this.responseText);
                    }
                    else
                    {
                        fnCallback(this.status, this.responseText);
                    }
                        
                    ajax.open("POST", "http://localhost:3000/izvjestaj", true);
                    ajax.setRequestHeader("Content-type", "application/json");
                    ajax.send(JSON.stringify(
                        {
                          spirala: spirala,
                          index: index
                      }
                    ))
                }
            }
            else
            {
                fnCallback(-1,"Neispravni parametri");
                return;
            }

        },
        kreirajBodove = function(spirala,index, fnCallback){
            if(index.length>0&&spirala.length>0)
            {
                var ajax=new XMLHttpRequest();
                ajax.onreadystatechange=function(){
                    if(ajax.readyState == 4 && ajax.status == 200)
                    {
                        fnCallback(null, this.responseText);
                    }
                    else
                    {
                        fnCallback(this.status, this.responseText);
                    }
                        
                    ajax.open("POST", "http://localhost:3000/bodovi", true);
                    ajax.setRequestHeader("Content-type", "application/json");
                    ajax.send(JSON.stringify(
                        {
                          spirala: spirala,
                          index: index
                      }
                    ))
                }
            }
            else
            {
                fnCallback(-1,"Neispravni parametri");
                return;
            }
        }
    }
})();



////////////////////////////////////////////////////////////////////////////


