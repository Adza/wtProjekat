var Poruke=(function(){
    var idDivaPoruka;
    var mogucePoruke=["Ime i prezime nije validno",
    "Indeks nije validan",
    "Akademska godina nije validna",
    "Password nije validan",
    "Potvrda passworda nije validna",
    "Bitbucket url nije validan",
    "Bitbucket ssh nije validan",
    "Naziv repozitorija nije validan",
    "E-mail nije validan",
    "Semestar nije validan"];
    var porukeZaIspis=["","","","","","","","","","",""];
    var porukeZaIspis2=["","","","","","","","","","",""];
    
    return{
    ispisiGreske: function(){
        var greske = document.getElementById("ListaPoruka");
        if (greske) {
            while (greske.firstChild) {
              greske.removeChild(greske.firstChild);
            }
          }

        //var greske=document.getElementById("porukee");
        //greske.textContent="";
        for(var i=0;i<porukeZaIspis.length;i++)
        {
            //var element = document.createElement("LI");
            //var textnode = document.createTextNode(porukeZaIspis[i]);
            //element.appendChild(textnode);
            //greske.appendChild(element);


            var element = document.createElement("li");
            element.appendChild(document.createTextNode(porukeZaIspis[i]));
            greske.appendChild(element);
           // greske.textContent=greske.textContent+" "+porukeZaIspis[i];   
        }

    },
    dodajPoruku: function(indeks){
        porukeZaIspis[indeks]=mogucePoruke[indeks];
    },
    obrisiPoruku: function(indeks){
        porukeZaIspis[indeks]="";
    }

    

    }
    }());